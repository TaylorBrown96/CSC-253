﻿/**
* 22NOV22
* CSC 253
* Taylor J. Brown
* This class holds the constructor for Pets
*/

namespace PetClassLibrary
{
    public class Pet
    {
        public Pet(string name, string type, string age)
        {
            Name = name;
            Type = type;
            Age = age;
        }

        public string Name { get; set; }
        public string Type { get; set; }
        public string Age { get; set; }
    }
}
