﻿/**
* 22NOV22
* CSC 253
* Taylor J. Brown
* This program Asks the user:
*   - How many pets they want to enter
*   - The pets information 
* Displays the pets information
* Then asks if there are more pets they need to enter
*   - Yes = Continues the program
*   - No = Terminates the program
*/

using System;
using System.Collections.Generic;
using System.Linq;
using PetClassLibrary;

namespace ConsoleUI
{
    internal class Program
    {
        public static List<Pet> pets = new List<Pet>();

        static void Main(string[] args)
        {
            bool keep_going = true;

            while (keep_going)
            {
                // Gets how many pets they want to enter
                Console.Write("How many pets do you want to enter?\n> ");
                int iterations;
                try
                {
                    iterations = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                }
                catch
                {
                    Console.WriteLine("Please enter a valid integer!\n");
                    continue;
                }

                // Gets the pets information and prints it out
                GetPetDetails(iterations);
                DisplayPetInfo();

                // Asks if they would like to enter more pets
                Console.Write("\nAre there more pets that you would like to enter?\n(yes or no) > ");

                // Validates the users input
                while (true)
                {
                    string usrInp = Console.ReadLine().ToLower();

                    if (usrInp.Equals("yes") || usrInp.Equals("y")) { keep_going = true; break; }
                    else if (usrInp.Equals("no") || usrInp.Equals("n")) { keep_going = false; break; }
                    else { Console.Write("\nPlease enter a valid option!\n(yes or no) > "); }
                }
                Console.WriteLine();
            }
        }

        // Gets the pets information and adds the pet object to the global list
        public static void GetPetDetails(int iterations)
        {
            string name;
            string type;
            string age;
            for (int i = 0 ; i < iterations; i++)
            {
                Console.WriteLine("Pet #" + (pets.Count() + 1));
                Console.Write("What is the pet's name?: ");
                name= Console.ReadLine();
                Console.Write("What type of pet is it?: ");
                type = Console.ReadLine();
                Console.Write("What is the pet's age?: ");
                age = Console.ReadLine();

                pets.Add(new Pet(name, type, age));
                Console.WriteLine();
            }
        }

        // Iterates through the global list and prints out the pet information
        public static void DisplayPetInfo()
        {
            Console.WriteLine("\nName:\tType:\tAge:");
            foreach(Pet pet in pets)
            {
                Console.WriteLine($"{pet.Name}\t{pet.Type}\t{pet.Age}");
            }
        }
    }
}
