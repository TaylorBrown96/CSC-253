﻿/**
* 22NOV22
* CSC 253
* Taylor J. Brown
* This program allows users to input information about their pets
* and displays the pets information back to the user
*/

using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using PetClassLibrary;

namespace WPFApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Pet> pets = new List<Pet>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Btn_Add_Click(object sender, RoutedEventArgs e)
        {
            string name;
            string type;
            string age;

            /*
             * Name 
            */
            // Checks to see if the field was filled out
            if (TB_Name.Text.Length == 0)
            {
                MessageBox.Show("You forgot to fill in the name field!", "Error!");
                return;
            }
            else
            {
                // Gets the name
                name = TB_Name.Text;
            }

            /*
             * Type 
            */
            // Checks to see if the field was filled out
            if (CB_Type.Text.Length == 0)
            {
                MessageBox.Show("You forgot to fill in the type field!", "Error!");
                return;
            }
            else
            {
                // Gets the type
                type = CB_Type.Text;
            }

            /*
             * Age
            */
            // Checks to see if the field was filled out
            if (TB_Age.Text.Length == 0)
            {
                MessageBox.Show("You forgot to fill in the age field!", "Error!");
                return;
            }
            else
            {
                // Gets the age
                age = TB_Age.Text;
            }

            // Creates the pet object
            Pet pet = new Pet(name, type, age);
            pets.Add(pet);

            // Adds details to the textbox
            TB_PetDetails.AppendText($"{pet.Name}\t{pet.Type}\t{pet.Age}\n");

            // Clears the input fields to make multiple submitions easier
            TB_Name.Text = "";
            CB_Type.Text = "";
            TB_Age.Text = "";
        }

        private void TB_Dialog_TextChanged(object sender, TextChangedEventArgs e)
        {
            TB_PetDetails.ScrollToEnd();
        }
    }
}

