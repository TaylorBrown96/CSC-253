﻿/**
* 29OCT22
* CSC 253
* Taylor J. Brown
* This class stores the query methods for the ProductDB
*/

using System.Collections.Generic;
using System.Linq;


namespace ProductSearchLibrary
{
    public class Queries
    {
        // Searches for product numbers that match the passed arg
        public static IEnumerable<Product> WhereProductNum(string arg, ProductDBDataContext db) =>
            from row in db.Products
            where row.Product_Number.ToLower().Equals(arg)
            select row;

        // Searches for product description that match the passed arg
        public static IEnumerable<Product> WhereProductDescription(string arg, ProductDBDataContext db) =>
            from row in db.Products
            where row.Description.ToLower().Contains(arg)
            select row;
    }
}
