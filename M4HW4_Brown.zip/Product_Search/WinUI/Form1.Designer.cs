﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DGV_DBContents = new System.Windows.Forms.DataGridView();
            this.productNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitsOnHandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productDBDataSet = new WinUI.ProductDBDataSet();
            this.productTableAdapter = new WinUI.ProductDBDataSetTableAdapters.ProductTableAdapter();
            this.TB_ProductNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_ProductNum = new System.Windows.Forms.Button();
            this.Btn_ProductDescription = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_ProductDescription = new System.Windows.Forms.TextBox();
            this.productBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.DGV_Results = new System.Windows.Forms.DataGridView();
            this.Product_Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Units_on_Hand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_DBContents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Results)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_DBContents
            // 
            this.DGV_DBContents.AutoGenerateColumns = false;
            this.DGV_DBContents.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.DGV_DBContents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_DBContents.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productNumberDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.unitsOnHandDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.DGV_DBContents.DataSource = this.productBindingSource;
            this.DGV_DBContents.Location = new System.Drawing.Point(13, 15);
            this.DGV_DBContents.Name = "DGV_DBContents";
            this.DGV_DBContents.ReadOnly = true;
            this.DGV_DBContents.Size = new System.Drawing.Size(460, 423);
            this.DGV_DBContents.TabIndex = 0;
            // 
            // productNumberDataGridViewTextBoxColumn
            // 
            this.productNumberDataGridViewTextBoxColumn.DataPropertyName = "Product_Number";
            this.productNumberDataGridViewTextBoxColumn.HeaderText = "Product_Number";
            this.productNumberDataGridViewTextBoxColumn.Name = "productNumberDataGridViewTextBoxColumn";
            this.productNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // unitsOnHandDataGridViewTextBoxColumn
            // 
            this.unitsOnHandDataGridViewTextBoxColumn.DataPropertyName = "Units_On_Hand";
            this.unitsOnHandDataGridViewTextBoxColumn.HeaderText = "Units_On_Hand";
            this.unitsOnHandDataGridViewTextBoxColumn.Name = "unitsOnHandDataGridViewTextBoxColumn";
            this.unitsOnHandDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.productDBDataSet;
            // 
            // productDBDataSet
            // 
            this.productDBDataSet.DataSetName = "ProductDBDataSet";
            this.productDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // TB_ProductNum
            // 
            this.TB_ProductNum.Location = new System.Drawing.Point(661, 12);
            this.TB_ProductNum.Name = "TB_ProductNum";
            this.TB_ProductNum.Size = new System.Drawing.Size(191, 20);
            this.TB_ProductNum.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(510, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search for a product number:";
            // 
            // Btn_ProductNum
            // 
            this.Btn_ProductNum.Location = new System.Drawing.Point(858, 10);
            this.Btn_ProductNum.Name = "Btn_ProductNum";
            this.Btn_ProductNum.Size = new System.Drawing.Size(75, 23);
            this.Btn_ProductNum.TabIndex = 3;
            this.Btn_ProductNum.Text = "Search";
            this.Btn_ProductNum.UseVisualStyleBackColor = true;
            this.Btn_ProductNum.Click += new System.EventHandler(this.Btn_ProductNum_Click);
            // 
            // Btn_ProductDescription
            // 
            this.Btn_ProductDescription.Location = new System.Drawing.Point(858, 44);
            this.Btn_ProductDescription.Name = "Btn_ProductDescription";
            this.Btn_ProductDescription.Size = new System.Drawing.Size(75, 23);
            this.Btn_ProductDescription.TabIndex = 6;
            this.Btn_ProductDescription.Text = "Search";
            this.Btn_ProductDescription.UseVisualStyleBackColor = true;
            this.Btn_ProductDescription.Click += new System.EventHandler(this.Btn_ProductDescription_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(488, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Search within product description:";
            // 
            // TB_ProductDescription
            // 
            this.TB_ProductDescription.Location = new System.Drawing.Point(661, 47);
            this.TB_ProductDescription.Name = "TB_ProductDescription";
            this.TB_ProductDescription.Size = new System.Drawing.Size(191, 20);
            this.TB_ProductDescription.TabIndex = 4;
            // 
            // productBindingSource1
            // 
            this.productBindingSource1.DataMember = "Product";
            this.productBindingSource1.DataSource = this.productDBDataSet;
            // 
            // DGV_Results
            // 
            this.DGV_Results.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Results.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Product_Number,
            this.Description,
            this.Units_on_Hand,
            this.Price});
            this.DGV_Results.Location = new System.Drawing.Point(480, 73);
            this.DGV_Results.Name = "DGV_Results";
            this.DGV_Results.Size = new System.Drawing.Size(458, 365);
            this.DGV_Results.TabIndex = 7;
            // 
            // Product_Number
            // 
            this.Product_Number.HeaderText = "Product_Number";
            this.Product_Number.Name = "Product_Number";
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            // 
            // Units_on_Hand
            // 
            this.Units_on_Hand.HeaderText = "Units_on_Hand";
            this.Units_on_Hand.Name = "Units_on_Hand";
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(950, 450);
            this.Controls.Add(this.DGV_Results);
            this.Controls.Add(this.Btn_ProductDescription);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TB_ProductDescription);
            this.Controls.Add(this.Btn_ProductNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_ProductNum);
            this.Controls.Add(this.DGV_DBContents);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Search";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_DBContents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Results)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_DBContents;
        private ProductDBDataSet productDBDataSet;
        private System.Windows.Forms.BindingSource productBindingSource;
        private ProductDBDataSetTableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitsOnHandDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox TB_ProductNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_ProductNum;
        private System.Windows.Forms.Button Btn_ProductDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_ProductDescription;
        private System.Windows.Forms.BindingSource productBindingSource1;
        private System.Windows.Forms.DataGridView DGV_Results;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Number;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Units_on_Hand;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
    }
}

