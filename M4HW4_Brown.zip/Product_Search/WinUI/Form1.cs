﻿/**
* 29OCT22
* CSC 253
* Taylor J. Brown
* This program displays the contents of the ProductsDB and allows
* the user to search based on two columns (Product_Number and Description)
*/

using System;
using System.Windows.Forms;
using ProductSearchLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Reads the textBox and send the argument to the 
        // WhereProductNum method. The program then loads the results to
        // the DGV_Results.
        private void Btn_ProductNum_Click(object sender, EventArgs e)
        {
            // Get user input and clear textbox
            string arg = TB_ProductNum.Text.ToLower();
            TB_ProductNum.Text = "";

            // Creates data context object
            ProductDBDataContext db = new ProductDBDataContext();
            var results = Queries.WhereProductNum(arg, db);

            // Clears the DGV_Results and loads the new results from the query
            DGV_Results.Rows.Clear();
            foreach (var row in results)
            {
                DGV_Results.Rows.Add(row.Product_Number, row.Description, row.Units_On_Hand, row.Price);
            }
        }

        // Reads the textBox and send the argument to the 
        // WhereProductDescription method. The program then loads the results to
        // the DGV_Results.
        private void Btn_ProductDescription_Click(object sender, EventArgs e)
        {
            // Get user input and clear textbox
            string arg = TB_ProductDescription.Text.ToLower();
            TB_ProductDescription.Text = "";

            // Creates data context object
            ProductDBDataContext db = new ProductDBDataContext();
            var results = Queries.WhereProductDescription(arg, db);

            // Clears the DGV_Results and loads the new results from the query
            DGV_Results.Rows.Clear();
            foreach (var row in results)
            {
                DGV_Results.Rows.Add(row.Product_Number, row.Description, row.Units_On_Hand, row.Price);
            }
        }



        // *** Auto-Generated Code *** //
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'productDBDataSet.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.productDBDataSet.Product);

        }
    }
}
