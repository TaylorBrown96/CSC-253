﻿/**
* 10SEP22
* CSC 253
* Taylor J. Brown
* This program displays the information that is stored in a database. 
* It also allows you to add a new record into the database
*/

using PersonnelLibrary;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<PersonModel> people = new List<PersonModel>();

        public Form1()
        {
            InitializeComponent();

            // Method call to populate the listBoxes
            LoadPeopleList();
        }

        private void LoadPeopleList()
        {
            // Method call to gather all records from the DB
            people = sqliteDataAccess.LoadPeople();

            PopulateLists();
        }

        private void PopulateLists()
        {
            // Clears the listboxes so this method can be used multiple times
            LB_EID.Items.Clear();
            LB_Name.Items.Clear();
            LB_Position.Items.Clear();
            LB_HR.Items.Clear();

            // Populates the listboxes for each record from the database
            foreach (PersonModel person in people)
            {
                LB_EID.Items.Add(person.employeeId);
                LB_Name.Items.Add(person.name);
                LB_Position.Items.Add(person.position);
                LB_HR.Items.Add(person.hourlyRate);
            }
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            // Pulls the name and position from the textBoxes on the form
            string name = TB_Name.Text;
            string position = TB_Position.Text;
            
            double hourly = 0.0;
            if (TB_Hourly.Text.Length != 0)
            {
                try
                {
                    // tries to convert the salary textbox to a double
                    hourly = Convert.ToDouble(TB_Hourly.Text);
                }
                catch
                {
                    MessageBox.Show("Please enter a valid double for the Hourly Pay Rate Field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Hourly.Text = "";
                    return;
                }
            }

            // Creates the person object 
            PersonModel person = new PersonModel();
            person.name = name;
            person.position = position;
            person.hourlyRate = hourly;

            // Sends person object to PersonnelLibrary to be saved to the DB
            sqliteDataAccess.SavePerson(person);

            // Clears the textBoxes for next entry
            TB_Name.Text = "";
            TB_Position.Text = "";
            TB_Hourly.Text = "";

            // Refreshes the listBoxes
            LoadPeopleList();
        }

        private void Btn_Ascending_Click(object sender, EventArgs e)
        {
            people.Sort(delegate (PersonModel x, PersonModel y) {
                return x.hourlyRate.CompareTo(y.hourlyRate);
            });

            PopulateLists();
        }

        private void Btn_Decending_Click(object sender, EventArgs e)
        {
            people.Sort(delegate (PersonModel x, PersonModel y) {
                return y.hourlyRate.CompareTo(x.hourlyRate);
            });

            PopulateLists();
        }
    }
}
