﻿/**
* 10SEP22
* CSC 253
* Taylor J. Brown
* This program displays the information that is stored in a database. 
* It also allows you to add a new record into the database
*/

namespace PersonnelLibrary
{
    // Auto-properties for when the records are pulled from the database
    public class PersonModel
    {
        // Auto-properties for each column in the DB table 
        public int employeeId { get; set; }
        public string name { get; set; }
        public string position { get; set; }
        public double hourlyRate { get; set; }
    }
}
