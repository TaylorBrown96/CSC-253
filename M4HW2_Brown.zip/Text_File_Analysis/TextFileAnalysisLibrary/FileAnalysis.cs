﻿/**
* 21OCT22
* CSC 253
* Taylor J. Brown
* This class contains methods to compares two text files 
* and returns the results
*/

using System.Collections.Generic;
using System.Linq;

namespace TextFileAnalysisLibrary
{
    public class FileAnalysis
    {
        public static List<string> UniqueInBoth(string[] file1, string[] file2)
        {
            // Adds both arrays elements into a single list
            List<string> result = file1.ToList();
            foreach (string word in file2) { result.Add(word); }

            // Uses the Distinct LINQ set method to delete duplicates
            var results = result.Distinct().ToList();

            // Removes all blank list items and return a list
            results.RemoveAll(x => x == "");
            return results;
        }

        public static List<string> AllWordsInFiles(string[] file1, string[] file2)
        {
            // Uses the Intersect LINQ set method to find the words that 
            // appear in both files
            List<string> results = file1.Intersect(file2).ToList();

            // Removes all blank list items and return a list
            results.RemoveAll(x => x == "");
            return results;
        }

        public static List<string> UniqueForFirst(string[] file1, string[] file2)
        {
            // Uses the Except LINQ set method to compare file1 to file2 then returns the result
            List<string> result = file1.Except(file2).ToList();
            return result;
        }

        public static List<string> UniqueForSecond(string[] file1, string[] file2)
        {
            // Uses the Except LINQ set method to compare file2 to file1 then returns the result
            List<string> result = file2.Except(file1).ToList();
            return result;
        }

        public static List<string> UniqueForBoth(string[] file1, string[] file2)
        {
            // Finds the unique words for each file
            List<string> result1 = file1.Except(file2).ToList();
            List<string> result2 = file2.Except(file1).ToList();

            // Adds the two lists together
            List<string> result = result1;
            foreach (string word in result2) { result.Add(word); }

            // Removes all blank list items and return a list
            result.RemoveAll(x => x == "");
            return result;
        }
    }
}
