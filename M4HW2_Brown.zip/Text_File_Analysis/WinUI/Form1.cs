﻿/**
* 21OCT22
* CSC 253
* Taylor J. Brown
* This program compares two text files and displays the results
*/

using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using TextFileAnalysisLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public string[] file1;
        public string[] file2;

        public Form1()
        {
            InitializeComponent();

            // Stores the first file as a string in a global variable and 
            // updates the richTextBox.
            RTB_File1Contents.Text = File.ReadAllText(@"File1.txt");
            file1 = File.ReadAllText(@"File1.txt").Split();

            // Stores the second file as a string in a global variable and 
            // updates the richTextBox.
            RTB_File2Contents.Text = File.ReadAllText(@"File2.txt");
            file2 = File.ReadAllText(@"File2.txt").Split();

            // Sends the files to all of the methods in the library
            List<string> uniqueInBoth = FileAnalysis.UniqueInBoth(file1,file2);
            List<string> allWords = FileAnalysis.AllWordsInFiles(file1, file2);
            List<string> uniqueFirst = FileAnalysis.UniqueForFirst(file1, file2);
            List<string> uniqueSecond = FileAnalysis.UniqueForSecond(file1, file2);
            List<string> uniqueForBoth = FileAnalysis.UniqueForBoth(file1, file2);

            // Populates the listBoxes with the results from the methods
            foreach (string word in uniqueInBoth) { LB_UniqueInBoth.Items.Add(word); }
            foreach (string word in allWords) { LB_WordsInBoth.Items.Add(word); }
            foreach (string word in uniqueFirst) { LB_InFirstNotSecond.Items.Add(word); }
            foreach (string word in uniqueSecond) { LB_InSecondNotFirst.Items.Add(word); }
            foreach (string word in uniqueForBoth) { LB_UniqueForBoth.Items.Add(word); }
        }
    }
}
