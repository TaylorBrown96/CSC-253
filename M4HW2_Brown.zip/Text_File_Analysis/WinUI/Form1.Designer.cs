﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_UniqueInBoth = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LB_WordsInBoth = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.LB_InFirstNotSecond = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LB_InSecondNotFirst = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.LB_UniqueForBoth = new System.Windows.Forms.ListBox();
            this.RTB_File1Contents = new System.Windows.Forms.RichTextBox();
            this.RTB_File2Contents = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LB_UniqueInBoth
            // 
            this.LB_UniqueInBoth.FormattingEnabled = true;
            this.LB_UniqueInBoth.Location = new System.Drawing.Point(13, 25);
            this.LB_UniqueInBoth.Name = "LB_UniqueInBoth";
            this.LB_UniqueInBoth.Size = new System.Drawing.Size(135, 355);
            this.LB_UniqueInBoth.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Unique words in both files:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(151, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Words in both files:";
            // 
            // LB_WordsInBoth
            // 
            this.LB_WordsInBoth.FormattingEnabled = true;
            this.LB_WordsInBoth.Location = new System.Drawing.Point(154, 25);
            this.LB_WordsInBoth.Name = "LB_WordsInBoth";
            this.LB_WordsInBoth.Size = new System.Drawing.Size(135, 355);
            this.LB_WordsInBoth.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(292, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Words in first file but not the second:";
            // 
            // LB_InFirstNotSecond
            // 
            this.LB_InFirstNotSecond.FormattingEnabled = true;
            this.LB_InFirstNotSecond.Location = new System.Drawing.Point(295, 27);
            this.LB_InFirstNotSecond.Name = "LB_InFirstNotSecond";
            this.LB_InFirstNotSecond.Size = new System.Drawing.Size(190, 355);
            this.LB_InFirstNotSecond.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(488, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Words in second file but not the first:";
            // 
            // LB_InSecondNotFirst
            // 
            this.LB_InSecondNotFirst.FormattingEnabled = true;
            this.LB_InSecondNotFirst.Location = new System.Drawing.Point(491, 27);
            this.LB_InSecondNotFirst.Name = "LB_InSecondNotFirst";
            this.LB_InSecondNotFirst.Size = new System.Drawing.Size(191, 355);
            this.LB_InSecondNotFirst.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(685, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Unique words for both files:";
            // 
            // LB_UniqueForBoth
            // 
            this.LB_UniqueForBoth.FormattingEnabled = true;
            this.LB_UniqueForBoth.Location = new System.Drawing.Point(688, 25);
            this.LB_UniqueForBoth.Name = "LB_UniqueForBoth";
            this.LB_UniqueForBoth.Size = new System.Drawing.Size(139, 355);
            this.LB_UniqueForBoth.TabIndex = 8;
            // 
            // RTB_File1Contents
            // 
            this.RTB_File1Contents.Location = new System.Drawing.Point(13, 407);
            this.RTB_File1Contents.Name = "RTB_File1Contents";
            this.RTB_File1Contents.ReadOnly = true;
            this.RTB_File1Contents.Size = new System.Drawing.Size(395, 429);
            this.RTB_File1Contents.TabIndex = 10;
            this.RTB_File1Contents.Text = "";
            // 
            // RTB_File2Contents
            // 
            this.RTB_File2Contents.Location = new System.Drawing.Point(429, 407);
            this.RTB_File2Contents.Name = "RTB_File2Contents";
            this.RTB_File2Contents.ReadOnly = true;
            this.RTB_File2Contents.Size = new System.Drawing.Size(398, 429);
            this.RTB_File2Contents.TabIndex = 11;
            this.RTB_File2Contents.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 387);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Contents of first file:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(426, 387);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Contents of second file:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(839, 848);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.RTB_File2Contents);
            this.Controls.Add(this.RTB_File1Contents);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LB_UniqueForBoth);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LB_InSecondNotFirst);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LB_InFirstNotSecond);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LB_WordsInBoth);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LB_UniqueInBoth);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Text File Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LB_UniqueInBoth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox LB_WordsInBoth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox LB_InFirstNotSecond;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox LB_InSecondNotFirst;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox LB_UniqueForBoth;
        private System.Windows.Forms.RichTextBox RTB_File1Contents;
        private System.Windows.Forms.RichTextBox RTB_File2Contents;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

