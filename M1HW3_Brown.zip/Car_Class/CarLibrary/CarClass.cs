﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This class creates and stores the car object it also 
* contains methods to modify the car object.
*/

using System.Collections.Generic;


namespace CarLibrary
{
    public class Car
    {
        // Public storage
        public static List<Car> Cars = new List<Car>();

        // Fields
        private int _year;
        private string _make;
        private int _speed;

        // Constructor
        public Car(int year,string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
        }

        // Year Make and Speed properties
        public int Year { get { return _year; } set { _year = value; }}
        public string Make { get { return _make; } set { _make = value; }}
        public int Speed { get { return _speed; } set { _speed = value; }}

        // Takes in the objects speed and increases it by five then returns it
        public static int Accelerate(int speed)
        {
            speed += 5;
            return speed;
        }

        // Takes in the objects speed and decreases it by five then returns it
        public static int Brake(int speed)
        {
            speed -= 5;
            return speed;
        }
    }
}
