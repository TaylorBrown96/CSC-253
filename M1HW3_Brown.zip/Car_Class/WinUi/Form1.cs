﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This program takes in a cars year and make and creates an object that you can 
* manipulate its speed variable with buttons on the form.
*/

using System;
using System.Windows.Forms;
using CarLibrary;

namespace WinUi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Create()
        {
            // Takes in the value from the textbox and assigns it to the year variable
            int year = 0;
            if (TB_Year.Text.Length != 0)
            {
                try
                {
                    year = Convert.ToInt32(TB_Year.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid Integer for the year field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Year.Text = "";
                    return;
                }
            }

            // Takes in the value from the textbox and assigns it to the make variable
            string make;
            if (TB_Make.Text.Length != 0)
            {
                try
                {
                    make = Convert.ToString(TB_Make.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid String for the make field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Make.Text = "";
                    return;
                }

                // Adds a new car object into the list
                Car.Cars.Add(new Car(year, make));

                // Updates all textboxes
                TB_OBJ_Year.Text = Car.Cars[0].Year.ToString();
                TB_OBJ_Make.Text = Car.Cars[0].Make.ToString();
                TB_OBJ_Speed.Text = Car.Cars[0].Speed.ToString();
            }
        }

        // When button is clicked this method first tries to delete the first object
        // in the list then it will procced to the Create method. 
        // If the operation fails it will procced to the Create method
        private void Btn_Load_Click(object sender, EventArgs e)
        {
            try
            {
                Car.Cars.RemoveAt(0);
                Create();
            }
            catch 
            {
                Create();
            }
        }

        // First the method checks the speed value to see if it is greater than 0.
        // Second it will send the objects speed value to the brake method and assign the returned value 
        // to the objects speed. Then it wil update the textbox.
        private void Btn_Brake_Click(object sender, EventArgs e)
        {
            if (Car.Cars[0].Speed == 0)
            {
                MessageBox.Show("It would seem that you are already stopped!", "Oops!");
                return;
            }
            Car.Cars[0].Speed = Car.Brake(Car.Cars[0].Speed);
            TB_OBJ_Speed.Text = Car.Cars[0].Speed.ToString();
        }

        // This method will send the objects speed value to the Accelerate method and assign the returned value 
        // to the objects speed. Then it wil update the textbox. 
        private void Btn_Accelerate_Click(object sender, EventArgs e)
        {
            Car.Cars[0].Speed = Car.Accelerate(Car.Cars[0].Speed);
            TB_OBJ_Speed.Text = Car.Cars[0].Speed.ToString();
        }
    }
}
