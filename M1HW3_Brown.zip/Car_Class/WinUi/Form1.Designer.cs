﻿namespace WinUi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.L_Year = new System.Windows.Forms.Label();
            this.TB_Year = new System.Windows.Forms.TextBox();
            this.L_Make = new System.Windows.Forms.Label();
            this.TB_Make = new System.Windows.Forms.TextBox();
            this.Btn_Load = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.L_OBJ_Year = new System.Windows.Forms.Label();
            this.L_OBJ_Make = new System.Windows.Forms.Label();
            this.TB_OBJ_Year = new System.Windows.Forms.TextBox();
            this.TB_OBJ_Make = new System.Windows.Forms.TextBox();
            this.L_Speed = new System.Windows.Forms.Label();
            this.TB_OBJ_Speed = new System.Windows.Forms.TextBox();
            this.Btn_Accelerate = new System.Windows.Forms.Button();
            this.Btn_Brake = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // L_Year
            // 
            this.L_Year.AutoSize = true;
            this.L_Year.Location = new System.Drawing.Point(13, 13);
            this.L_Year.Name = "L_Year";
            this.L_Year.Size = new System.Drawing.Size(29, 13);
            this.L_Year.TabIndex = 0;
            this.L_Year.Text = "Year";
            // 
            // TB_Year
            // 
            this.TB_Year.Location = new System.Drawing.Point(13, 30);
            this.TB_Year.Name = "TB_Year";
            this.TB_Year.Size = new System.Drawing.Size(100, 20);
            this.TB_Year.TabIndex = 1;
            // 
            // L_Make
            // 
            this.L_Make.AutoSize = true;
            this.L_Make.Location = new System.Drawing.Point(16, 57);
            this.L_Make.Name = "L_Make";
            this.L_Make.Size = new System.Drawing.Size(34, 13);
            this.L_Make.TabIndex = 2;
            this.L_Make.Text = "Make";
            // 
            // TB_Make
            // 
            this.TB_Make.Location = new System.Drawing.Point(13, 74);
            this.TB_Make.Name = "TB_Make";
            this.TB_Make.Size = new System.Drawing.Size(100, 20);
            this.TB_Make.TabIndex = 3;
            // 
            // Btn_Load
            // 
            this.Btn_Load.Location = new System.Drawing.Point(13, 101);
            this.Btn_Load.Name = "Btn_Load";
            this.Btn_Load.Size = new System.Drawing.Size(100, 23);
            this.Btn_Load.TabIndex = 4;
            this.Btn_Load.Text = "Load Car";
            this.Btn_Load.UseVisualStyleBackColor = true;
            this.Btn_Load.Click += new System.EventHandler(this.Btn_Load_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(232, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Car Information";
            // 
            // L_OBJ_Year
            // 
            this.L_OBJ_Year.AutoSize = true;
            this.L_OBJ_Year.Location = new System.Drawing.Point(153, 32);
            this.L_OBJ_Year.Name = "L_OBJ_Year";
            this.L_OBJ_Year.Size = new System.Drawing.Size(32, 13);
            this.L_OBJ_Year.TabIndex = 6;
            this.L_OBJ_Year.Text = "Year:";
            // 
            // L_OBJ_Make
            // 
            this.L_OBJ_Make.AutoSize = true;
            this.L_OBJ_Make.Location = new System.Drawing.Point(258, 32);
            this.L_OBJ_Make.Name = "L_OBJ_Make";
            this.L_OBJ_Make.Size = new System.Drawing.Size(37, 13);
            this.L_OBJ_Make.TabIndex = 7;
            this.L_OBJ_Make.Text = "Make:";
            // 
            // TB_OBJ_Year
            // 
            this.TB_OBJ_Year.Location = new System.Drawing.Point(191, 29);
            this.TB_OBJ_Year.Name = "TB_OBJ_Year";
            this.TB_OBJ_Year.ReadOnly = true;
            this.TB_OBJ_Year.Size = new System.Drawing.Size(60, 20);
            this.TB_OBJ_Year.TabIndex = 8;
            // 
            // TB_OBJ_Make
            // 
            this.TB_OBJ_Make.Location = new System.Drawing.Point(301, 29);
            this.TB_OBJ_Make.Name = "TB_OBJ_Make";
            this.TB_OBJ_Make.ReadOnly = true;
            this.TB_OBJ_Make.Size = new System.Drawing.Size(76, 20);
            this.TB_OBJ_Make.TabIndex = 9;
            // 
            // L_Speed
            // 
            this.L_Speed.AutoSize = true;
            this.L_Speed.Location = new System.Drawing.Point(153, 74);
            this.L_Speed.Name = "L_Speed";
            this.L_Speed.Size = new System.Drawing.Size(104, 13);
            this.L_Speed.TabIndex = 10;
            this.L_Speed.Text = "Car\'s Current Speed:";
            // 
            // TB_OBJ_Speed
            // 
            this.TB_OBJ_Speed.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_OBJ_Speed.Location = new System.Drawing.Point(261, 57);
            this.TB_OBJ_Speed.Name = "TB_OBJ_Speed";
            this.TB_OBJ_Speed.ReadOnly = true;
            this.TB_OBJ_Speed.Size = new System.Drawing.Size(116, 44);
            this.TB_OBJ_Speed.TabIndex = 11;
            // 
            // Btn_Accelerate
            // 
            this.Btn_Accelerate.Location = new System.Drawing.Point(272, 125);
            this.Btn_Accelerate.Name = "Btn_Accelerate";
            this.Btn_Accelerate.Size = new System.Drawing.Size(75, 23);
            this.Btn_Accelerate.TabIndex = 12;
            this.Btn_Accelerate.Text = "Accelerate";
            this.Btn_Accelerate.UseVisualStyleBackColor = true;
            this.Btn_Accelerate.Click += new System.EventHandler(this.Btn_Accelerate_Click);
            // 
            // Btn_Brake
            // 
            this.Btn_Brake.Location = new System.Drawing.Point(191, 125);
            this.Btn_Brake.Name = "Btn_Brake";
            this.Btn_Brake.Size = new System.Drawing.Size(75, 23);
            this.Btn_Brake.TabIndex = 13;
            this.Btn_Brake.Text = "Brake";
            this.Btn_Brake.UseVisualStyleBackColor = true;
            this.Btn_Brake.Click += new System.EventHandler(this.Btn_Brake_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 165);
            this.Controls.Add(this.Btn_Brake);
            this.Controls.Add(this.Btn_Accelerate);
            this.Controls.Add(this.TB_OBJ_Speed);
            this.Controls.Add(this.L_Speed);
            this.Controls.Add(this.TB_OBJ_Make);
            this.Controls.Add(this.TB_OBJ_Year);
            this.Controls.Add(this.L_OBJ_Make);
            this.Controls.Add(this.L_OBJ_Year);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Btn_Load);
            this.Controls.Add(this.TB_Make);
            this.Controls.Add(this.L_Make);
            this.Controls.Add(this.TB_Year);
            this.Controls.Add(this.L_Year);
            this.Name = "Form1";
            this.Text = "Car Class";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_Year;
        private System.Windows.Forms.TextBox TB_Year;
        private System.Windows.Forms.Label L_Make;
        private System.Windows.Forms.TextBox TB_Make;
        private System.Windows.Forms.Button Btn_Load;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label L_OBJ_Year;
        private System.Windows.Forms.Label L_OBJ_Make;
        private System.Windows.Forms.TextBox TB_OBJ_Year;
        private System.Windows.Forms.TextBox TB_OBJ_Make;
        private System.Windows.Forms.Label L_Speed;
        private System.Windows.Forms.TextBox TB_OBJ_Speed;
        private System.Windows.Forms.Button Btn_Accelerate;
        private System.Windows.Forms.Button Btn_Brake;
    }
}

