﻿/**
* 24SEP22
* CSC 253
* Taylor J. Brown
* This program allows you to interact with a database
*/

using System;
using System.Windows.Forms;
using PopulationClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            Validate();
            cityBindingSource.EndEdit();
            tableAdapterManager.UpdateAll(populationDBDataSet);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            cityTableAdapter.Fill(populationDBDataSet.City);

        }

        private void Btn_LowPop_Click(object sender, EventArgs e)
        {
            cityTableAdapter.FillByMinPop(populationDBDataSet.City);
        }

        private void Btn_highPop_Click(object sender, EventArgs e)
        {
            cityTableAdapter.FillByMaxPop(populationDBDataSet.City);
        }

        private void Btn_totalPop_Click(object sender, EventArgs e)
        {
            var totalPop = cityTableAdapter.TotalPop();
            DisplayMessages.Message(Convert.ToString(totalPop),"Total Population");
        }

        private void Btn_avgPop_Click(object sender, EventArgs e)
        {
            var avgPop = cityTableAdapter.AvgPop();
            DisplayMessages.Message(Convert.ToString(avgPop), "Average Population");
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            cityTableAdapter.Fill(populationDBDataSet.City);
        }
    }
}
