﻿/**
* 24SEP22
* CSC 253
* Taylor J. Brown
* This program allows you to interact with a database
*/

using System.Windows.Forms;

namespace PopulationClassLibrary
{
    public class DisplayMessages
    {
        public static void Message(string message,string title)
        {
            MessageBox.Show(message, title);
        }
    }
}
