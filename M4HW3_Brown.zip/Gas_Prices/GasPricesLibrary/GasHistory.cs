﻿/**
* 28OCT22
* CSC 253
* Taylor J. Brown
* This class creates record objects for each line in the GasPrices.txt file
*/


namespace GasPricesLibrary
{
    public class GasHistory
    {
        // Format of the file data * MM-DD-YYYY:Price *

        public GasHistory(int month, int day, int year, double price)
        {
            Month = month;
            Day = day;
            Year = year;
            Price = price;
        }

        public int Month { get; set; }
        public int Day { get; set; }
        public int Year { get; set; }
        public double Price { get; set; }
    }
}
