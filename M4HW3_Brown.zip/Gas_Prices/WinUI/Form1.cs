﻿/**
* 28OCT22
* CSC 253
* Taylor J. Brown
* This program displays the contents of the GasPrice.txt file
*/

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using GasPricesLibrary;


namespace WinUI
{
    public partial class Form1 : Form
    {
        public static List<GasHistory> history = new List<GasHistory>();
        public Form1()
        {
            InitializeComponent();
            
            // Opens the GasPrices.txt file and stores the data
            // in a list of objects.
            ReadFile();

            // Populates the DataGridViews on the form
            LoadData();
            YearAverage();
            MonthAverage();
            HighLow();
        }

        private void ReadFile()
        {
            // Reads the files contents
            string[] data = File.ReadAllText(@"GasPrices.txt").Split('\n');

            // Creates objects based on the read lines of the file
            foreach (string record in data)
            {
                // Gets the prices data
                string[] arr = record.Split(':');
                double price = Convert.ToDouble(arr[1]);

                // Gets the month day year data
                string[] date = arr[0].Split('-');
                int month = Convert.ToInt32(date[0]);
                int day = Convert.ToInt32(date[1]);
                int year = Convert.ToInt32(date[2]);

                // Creates and adds a record object to the global list
                history.Add(new GasHistory(month, day, year, price));
            }
        }

        private void LoadData()
        {
            // Adds each objects data to the DataGridView
            foreach (GasHistory record in history)
            {
                // Adds the result to the DataGridView
                DGV_PriceRecords.Rows.Add(record.Month + "-" + record.Day + "-" + record.Year, record.Price);
            }
        }

        private void YearAverage()
        {
            // Gets the average price for each year in the list
            for (int i = 1993; i <= 2013; i++)
            {
                // Finds all records that match the current year index
                List<GasHistory> year = history.FindAll(a => a.Year == i);

                // Calculates the average for all found matches
                var average = year.Average(a => a.Price);

                // Adds the result to the DataGridView
                DGV_AverageYear.Rows.Add(i, average);
            }
        }

        private void MonthAverage()
        {
            // Gets the average price for each month in the list
            for (int i = 1; i <= 12; i++)
            {
                // Finds all records that match the current month index
                List<GasHistory> month = history.FindAll(a => a.Month == i);

                // Calculates the average for all found matches
                var average = month.Average(a => a.Price);

                // Array of the names of each month
                string[] months = { "January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

                // Adds the result to the DataGridView
                DGV_AverageMonth.Rows.Add(months[i - 1], average);
            }
        }

        private void HighLow()
        {
            // Gets the lowest and highest prices for each year in the list 
            for (int i = 1993; i <= 2013; i++)
            {
                // Finds all records that match the current year index
                List<GasHistory> year = history.FindAll(a => a.Year == i);

                // Finds the lowest price and creates a string
                var min = year.Min(a => a.Price);
                var minDate = history.Find(a => a.Price == min);
                string minDateS = minDate.Month.ToString() + "-" + minDate.Day.ToString() + "-" + minDate.Year.ToString();

                // Finds the highest price and creates a string
                var max = year.Max(a => a.Price);
                var maxDate = history.Find(a => a.Price == max);
                string maxDateS = maxDate.Month.ToString() + "-" + maxDate.Day.ToString() + "-" + maxDate.Year.ToString();

                // Adds the result to the DataGridView
                DGV_High_Low.Rows.Add("Lowest", minDateS, min);
                DGV_High_Low.Rows.Add("Highest", maxDateS, max);
            }
        }

        private void Btn_Low_High_Click(object sender, EventArgs e)
        {
            // Sets up the saveFileDialog window
            SFD_Lowest_Highest.InitialDirectory = @"C:\";      
            SFD_Lowest_Highest.Title = "Save text File";
            SFD_Lowest_Highest.DefaultExt = "txt";
            SFD_Lowest_Highest.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";
            SFD_Lowest_Highest.RestoreDirectory = true;

            // Sorts the history list from lowest to highest and
            // saves the result to a text file.
            if (SFD_Lowest_Highest.ShowDialog() == DialogResult.OK)
            {
                // Orders the list from lowest to highest
                var lowHigh = history.OrderBy(x => x.Price).ToList();

                // Creates and writes the data to the file
                TextWriter txt = new StreamWriter(SFD_Lowest_Highest.FileName);
                foreach (GasHistory record in lowHigh)
                {
                    txt.WriteLine(record.Month + "-" + record.Day + "-" + record.Year + ":" + record.Price);
                }
                txt.Close();
            }
            else
            {
                // If an error occurs a messageBox will appear 
                MessageBox.Show("An Error has Occured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Btn_High_Low_Click(object sender, EventArgs e)
        {
            // Sets up the saveFileDialog window
            SFD_Highest_Lowest.InitialDirectory = @"C:\";
            SFD_Highest_Lowest.Title = "Save text File";
            SFD_Highest_Lowest.DefaultExt = "txt";
            SFD_Highest_Lowest.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";
            SFD_Highest_Lowest.RestoreDirectory = true;

            // Sorts the history list from highest to lowest and
            // saves the result to a text file.
            if (SFD_Highest_Lowest.ShowDialog() == DialogResult.OK)
            {
                // Orders the list from highest to lowest
                var highLow = history.OrderByDescending(x => x.Price).ToList();

                // Creates and writes the data to the file
                TextWriter txt = new StreamWriter(SFD_Highest_Lowest.FileName);
                foreach (GasHistory record in highLow)
                {
                    txt.WriteLine(record.Month + "-" + record.Day + "-" + record.Year + ":" + record.Price);
                }
                txt.Close();
            }
            else
            {
                // If an error occurs a messageBox will appear
                MessageBox.Show("An Error has Occured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
