﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV_PriceRecords = new System.Windows.Forms.DataGridView();
            this.RecordDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RecordPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_AverageYear = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DGV_AverageMonth = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.DGV_High_Low = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.Btn_Low_High = new System.Windows.Forms.Button();
            this.Btn_High_Low = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.High_Low = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HLDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HLPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AverageMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Year = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AverageYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SFD_Lowest_Highest = new System.Windows.Forms.SaveFileDialog();
            this.SFD_Highest_Lowest = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_PriceRecords)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AverageYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AverageMonth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_High_Low)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_PriceRecords
            // 
            this.DGV_PriceRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_PriceRecords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RecordDate,
            this.RecordPrice});
            this.DGV_PriceRecords.Location = new System.Drawing.Point(13, 28);
            this.DGV_PriceRecords.Name = "DGV_PriceRecords";
            this.DGV_PriceRecords.Size = new System.Drawing.Size(266, 407);
            this.DGV_PriceRecords.TabIndex = 0;
            // 
            // RecordDate
            // 
            this.RecordDate.HeaderText = "Date";
            this.RecordDate.Name = "RecordDate";
            this.RecordDate.ReadOnly = true;
            // 
            // RecordPrice
            // 
            this.RecordPrice.HeaderText = "Price";
            this.RecordPrice.Name = "RecordPrice";
            this.RecordPrice.ReadOnly = true;
            // 
            // DGV_AverageYear
            // 
            this.DGV_AverageYear.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_AverageYear.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Year,
            this.AverageYear});
            this.DGV_AverageYear.Location = new System.Drawing.Point(309, 28);
            this.DGV_AverageYear.Name = "DGV_AverageYear";
            this.DGV_AverageYear.Size = new System.Drawing.Size(277, 407);
            this.DGV_AverageYear.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "All File Data:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(309, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Average Price Per Year:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(619, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Average Price Per Month:";
            // 
            // DGV_AverageMonth
            // 
            this.DGV_AverageMonth.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_AverageMonth.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Month,
            this.AverageMonth});
            this.DGV_AverageMonth.Location = new System.Drawing.Point(619, 28);
            this.DGV_AverageMonth.Name = "DGV_AverageMonth";
            this.DGV_AverageMonth.Size = new System.Drawing.Size(258, 407);
            this.DGV_AverageMonth.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(909, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "High/Low Price Per Year:";
            // 
            // DGV_High_Low
            // 
            this.DGV_High_Low.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_High_Low.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.High_Low,
            this.HLDate,
            this.HLPrice});
            this.DGV_High_Low.Location = new System.Drawing.Point(909, 28);
            this.DGV_High_Low.Name = "DGV_High_Low";
            this.DGV_High_Low.Size = new System.Drawing.Size(366, 407);
            this.DGV_High_Low.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1374, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "List of Prices, Lowest to Highest:";
            // 
            // Btn_Low_High
            // 
            this.Btn_Low_High.Location = new System.Drawing.Point(1398, 180);
            this.Btn_Low_High.Name = "Btn_Low_High";
            this.Btn_Low_High.Size = new System.Drawing.Size(107, 23);
            this.Btn_Low_High.TabIndex = 9;
            this.Btn_Low_High.Text = "Generate .txt File";
            this.Btn_Low_High.UseVisualStyleBackColor = true;
            this.Btn_Low_High.Click += new System.EventHandler(this.Btn_Low_High_Click);
            // 
            // Btn_High_Low
            // 
            this.Btn_High_Low.Location = new System.Drawing.Point(1398, 238);
            this.Btn_High_Low.Name = "Btn_High_Low";
            this.Btn_High_Low.Size = new System.Drawing.Size(107, 23);
            this.Btn_High_Low.TabIndex = 11;
            this.Btn_High_Low.Text = "Generate .txt File";
            this.Btn_High_Low.UseVisualStyleBackColor = true;
            this.Btn_High_Low.Click += new System.EventHandler(this.Btn_High_Low_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1374, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "List of Prices, Highest to Lowest:";
            // 
            // High_Low
            // 
            this.High_Low.HeaderText = "High/Low";
            this.High_Low.Name = "High_Low";
            this.High_Low.ReadOnly = true;
            // 
            // HLDate
            // 
            this.HLDate.HeaderText = "Date";
            this.HLDate.Name = "HLDate";
            this.HLDate.ReadOnly = true;
            // 
            // HLPrice
            // 
            this.HLPrice.HeaderText = "Price";
            this.HLPrice.Name = "HLPrice";
            this.HLPrice.ReadOnly = true;
            // 
            // Month
            // 
            this.Month.HeaderText = "Month";
            this.Month.Name = "Month";
            this.Month.ReadOnly = true;
            // 
            // AverageMonth
            // 
            this.AverageMonth.HeaderText = "Average";
            this.AverageMonth.Name = "AverageMonth";
            this.AverageMonth.ReadOnly = true;
            this.AverageMonth.Width = 110;
            // 
            // Year
            // 
            this.Year.HeaderText = "Year";
            this.Year.Name = "Year";
            this.Year.ReadOnly = true;
            // 
            // AverageYear
            // 
            this.AverageYear.HeaderText = "Average";
            this.AverageYear.Name = "AverageYear";
            this.AverageYear.ReadOnly = true;
            this.AverageYear.Width = 110;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1611, 448);
            this.Controls.Add(this.Btn_High_Low);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Btn_Low_High);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.DGV_High_Low);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DGV_AverageMonth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGV_AverageYear);
            this.Controls.Add(this.DGV_PriceRecords);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gas Prices";
            ((System.ComponentModel.ISupportInitialize)(this.DGV_PriceRecords)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AverageYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_AverageMonth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_High_Low)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_PriceRecords;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecordDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecordPrice;
        private System.Windows.Forms.DataGridView DGV_AverageYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView DGV_AverageMonth;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView DGV_High_Low;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Btn_Low_High;
        private System.Windows.Forms.Button Btn_High_Low;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn High_Low;
        private System.Windows.Forms.DataGridViewTextBoxColumn HLDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn HLPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month;
        private System.Windows.Forms.DataGridViewTextBoxColumn AverageMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn Year;
        private System.Windows.Forms.DataGridViewTextBoxColumn AverageYear;
        private System.Windows.Forms.SaveFileDialog SFD_Lowest_Highest;
        private System.Windows.Forms.SaveFileDialog SFD_Highest_Lowest;
    }
}

