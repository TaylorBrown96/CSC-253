﻿/**
* 20NOV22
* CSC 253
* Taylor J. Brown
* This test library tests the CalculateIncrease method in the TuitionInclearseLibrary
*/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using TuitionIncreaseLibrary;

namespace TuitionIncreaseLibrary.test
{
    [TestClass]
    public class Increase
    {
        [TestMethod]
        [DataRow(6000.00, "6120.00", "6242.40", "6367.25", "6494.59", "6624.48")]
        [DataRow(8000.00, "8160.00", "8323.20", "8489.66", "8659.46", "8832.65")]
        [DataRow(12000.00, "12240.00", "12484.80", "12734.50", "12989.19", "13248.97")]
        public void CalculateIncrease_Test(double currentRate, string expectedYear1, string expectedYear2, string expectedYear3, string expectedYear4, string expectedYear5)
        {
            // Arrange
            decimal CurrentRate = Convert.ToDecimal(currentRate);

            // Act
            List<decimal> Actual = Calculate.Increase(CurrentRate);

            string ActualYear1 = Actual[0].ToString("0.00");
            string ActualYear2 = Actual[1].ToString("0.00");
            string ActualYear3 = Actual[2].ToString("0.00");
            string ActualYear4 = Actual[3].ToString("0.00");
            string ActualYear5 = Actual[4].ToString("0.00");

            // Assert
            Assert.AreEqual(expectedYear1, ActualYear1);
            Assert.AreEqual(expectedYear2, ActualYear2);
            Assert.AreEqual(expectedYear3, ActualYear3);
            Assert.AreEqual(expectedYear4, ActualYear4);
            Assert.AreEqual(expectedYear5, ActualYear5);
        }
    }
}
