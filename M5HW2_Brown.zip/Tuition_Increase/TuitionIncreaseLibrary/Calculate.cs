﻿/**
* 20NOV22
* CSC 253
* Taylor J. Brown
* This library takes in the current rate and sends back a list of the new rate increases 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionIncreaseLibrary
{
    public class Calculate
    {
        // takes in the current rate and increases it incrementaly.
        // Finally it returns the newly populated list
        public static List<decimal> Increase(decimal currentRate)
        {
            List<decimal> results = new List<decimal>();

            for ( int i = 0; i < 5; i++)
            {
                decimal temp = currentRate * (decimal)0.02;

                currentRate += temp;

                results.Add(currentRate);
            }

            return results;
        }
    }
}
