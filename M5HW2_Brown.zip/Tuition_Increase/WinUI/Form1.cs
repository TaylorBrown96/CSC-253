﻿/**
* 20NOV22
* CSC 253
* Taylor J. Brown
* This program shoes the year to year increase of tuition 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuitionIncreaseLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            // Set the current rate and retrieve a list of the increases
            decimal currentRate = 6000M;
            List<decimal> tuitions = Calculate.Increase(currentRate);

            // Populates the form with the collected data
            L_Year1.Text = "$" + tuitions[0].ToString("0.00");
            L_Year2.Text = "$" + tuitions[1].ToString("0.00");
            L_Year3.Text = "$" + tuitions[2].ToString("0.00");
            L_Year4.Text = "$" + tuitions[3].ToString("0.00");
            L_Year5.Text = "$" + tuitions[4].ToString("0.00");
        }
    }
}
