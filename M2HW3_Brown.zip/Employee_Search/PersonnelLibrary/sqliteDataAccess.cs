﻿/**
* 10SEP22
* CSC 253
* Taylor J. Brown
* This program displays the information that is stored in a database. 
* It also allows you to add a new record into the database
*/

using Dapper;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;

namespace PersonnelLibrary
{
    public class sqliteDataAccess
    {
        // Does a select query to gather all records and their fields from the DB
        public static List<PersonModel> LoadPeople()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<PersonModel>("select * from Employees", new DynamicParameters());
                return output.ToList();
            }
        }

        // Saves a passed person object to the database as a record
        public static void SavePerson(PersonModel person)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Employees (name, position, hourlyRate) values (@name, @position, @hourlyRate)", person);
            }
        }

        // Connection string
        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }
}
