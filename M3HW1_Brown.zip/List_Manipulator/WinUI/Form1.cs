﻿/**
* 30SEP22
* CSC 253
* Taylor J. Brown
* This program takes in a file of random numbers and manipulates it on a button event
*/

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ListManipulatorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public static List<int> Nums = new List<int>();

        public Form1()
        {
            InitializeComponent();

            // Sends the global list to get populated by the random.txt file
            Nums = FileReader.ReadFile(Nums);
            LoadListBox(Nums);
        }

        // Loads the list items into the listbox
        private void LoadListBox(List<int> Nums)
        {
            LB_RandomNums.Items.Clear();

            foreach (int num in Nums)
            {
                LB_RandomNums.Items.Add(num);
            }
        }

        // Removes any negative number in the Global list and repopulates the listbox 
        private void Btn_RemoveNeg_Click(object sender, EventArgs e)
        {
            Nums.RemoveAll(a => a < 0);
            LoadListBox(Nums);
        }

        // Populates a new list with all number that are in range of 1 to 10
        private void Btn_FindRange_Click(object sender, EventArgs e)
        {
            List<int> NumsInRange = Nums.FindAll(a => a >= 1 && a <=10);

            LB_InRange.Items.Clear();

            foreach (int num in NumsInRange)
            {
                LB_InRange.Items.Add(num);
            }
        }

        // Resets the global list and calls the readfile method to load the list again
        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            Nums.Clear();
            Nums = FileReader.ReadFile(Nums);
            LoadListBox(Nums);
        }
    }
}
