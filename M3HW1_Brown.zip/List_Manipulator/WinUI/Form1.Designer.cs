﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_RandomNums = new System.Windows.Forms.ListBox();
            this.L_RandomNums = new System.Windows.Forms.Label();
            this.Btn_RemoveNeg = new System.Windows.Forms.Button();
            this.Btn_FindRange = new System.Windows.Forms.Button();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.LB_InRange = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // LB_RandomNums
            // 
            this.LB_RandomNums.FormattingEnabled = true;
            this.LB_RandomNums.Location = new System.Drawing.Point(12, 29);
            this.LB_RandomNums.Name = "LB_RandomNums";
            this.LB_RandomNums.Size = new System.Drawing.Size(120, 329);
            this.LB_RandomNums.TabIndex = 0;
            // 
            // L_RandomNums
            // 
            this.L_RandomNums.AutoSize = true;
            this.L_RandomNums.Location = new System.Drawing.Point(13, 13);
            this.L_RandomNums.Name = "L_RandomNums";
            this.L_RandomNums.Size = new System.Drawing.Size(92, 13);
            this.L_RandomNums.TabIndex = 1;
            this.L_RandomNums.Text = "Random Numbers";
            // 
            // Btn_RemoveNeg
            // 
            this.Btn_RemoveNeg.Location = new System.Drawing.Point(161, 29);
            this.Btn_RemoveNeg.Name = "Btn_RemoveNeg";
            this.Btn_RemoveNeg.Size = new System.Drawing.Size(86, 36);
            this.Btn_RemoveNeg.TabIndex = 2;
            this.Btn_RemoveNeg.Text = "Remove Negatives";
            this.Btn_RemoveNeg.UseVisualStyleBackColor = true;
            this.Btn_RemoveNeg.Click += new System.EventHandler(this.Btn_RemoveNeg_Click);
            // 
            // Btn_FindRange
            // 
            this.Btn_FindRange.Location = new System.Drawing.Point(161, 71);
            this.Btn_FindRange.Name = "Btn_FindRange";
            this.Btn_FindRange.Size = new System.Drawing.Size(86, 37);
            this.Btn_FindRange.TabIndex = 3;
            this.Btn_FindRange.Text = "Find Nums between 1-10";
            this.Btn_FindRange.UseVisualStyleBackColor = true;
            this.Btn_FindRange.Click += new System.EventHandler(this.Btn_FindRange_Click);
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.Location = new System.Drawing.Point(161, 335);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(86, 23);
            this.Btn_Reset.TabIndex = 4;
            this.Btn_Reset.Text = "Reset";
            this.Btn_Reset.UseVisualStyleBackColor = true;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // LB_InRange
            // 
            this.LB_InRange.FormattingEnabled = true;
            this.LB_InRange.Location = new System.Drawing.Point(161, 114);
            this.LB_InRange.Name = "LB_InRange";
            this.LB_InRange.Size = new System.Drawing.Size(86, 212);
            this.LB_InRange.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 372);
            this.Controls.Add(this.LB_InRange);
            this.Controls.Add(this.Btn_Reset);
            this.Controls.Add(this.Btn_FindRange);
            this.Controls.Add(this.Btn_RemoveNeg);
            this.Controls.Add(this.L_RandomNums);
            this.Controls.Add(this.LB_RandomNums);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List Manipulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LB_RandomNums;
        private System.Windows.Forms.Label L_RandomNums;
        private System.Windows.Forms.Button Btn_RemoveNeg;
        private System.Windows.Forms.Button Btn_FindRange;
        private System.Windows.Forms.Button Btn_Reset;
        private System.Windows.Forms.ListBox LB_InRange;
    }
}

