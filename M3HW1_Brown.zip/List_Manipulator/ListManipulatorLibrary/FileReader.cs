﻿/**
* 30SEP22
* CSC 253
* Taylor J. Brown
* This program takes in a file of random numbers and manipulates it on a button event
*/

using System.Collections.Generic;
using System.IO;

namespace ListManipulatorLibrary
{
    public class FileReader
    {
        // Reads the random.txt and populates the passed list
        // and return the updated list
        public static List<int> ReadFile(List<int> list)
        {
            string line;

            StreamReader reader = File.OpenText("random.txt");
            while ((line = reader.ReadLine()) != null)
            {
                list.Add(int.Parse(line));
            }
            reader.Close();

            return list;
        }
    }
}
