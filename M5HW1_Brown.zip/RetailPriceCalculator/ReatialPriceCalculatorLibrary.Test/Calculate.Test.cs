﻿/**
* 10NOV22
* CSC 253
* Taylor J. Brown
* This unit test file tests the CalculateRetail method in the RetailPriceCalculatorLibrary
*/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;


namespace RetailPriceCalculatorLibrary.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [DataRow(50.00, 5.0, 52.50)]
        [DataRow(70.00, 15.0, 80.50)]
        [DataRow(35, 150.0, 87.50)]
        [DataRow(17.00, 88.0, 31.96)]
        public void CalculateRetail_Test(double wholesale_cost, double markup_percentage, double expected)
        {
            // Arrange
            decimal Wholesale_cost = Convert.ToDecimal(wholesale_cost);
            decimal Markup_percentage = Convert.ToDecimal(markup_percentage);
            decimal Expected = Convert.ToDecimal(expected);

            // Act
            decimal Actual = Calculate.CalculateRetail(Wholesale_cost, Markup_percentage);

            // Assert
            Assert.AreEqual(Expected, Actual);
        }
    }
}
