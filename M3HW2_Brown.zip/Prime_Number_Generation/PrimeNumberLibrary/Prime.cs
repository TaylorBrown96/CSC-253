﻿/**
* 30SEP22
* CSC 253
* Taylor Brown
* Generates a list of prime numbers within a range of the users choosing
*/

using System;
using System.Collections.Generic;
using System.Linq;

namespace PrimeNumberLibrary
{
    public class Prime
    {
        // Iterates through a list and checks to see if it is a prime number
        public static List<int> FindPrimes(List<int> nums)
        {
            List<int> ints = nums.FindAll(a => Enumerable.Range(2, (int)Math.Sqrt(a) - 1).All(divisor => a % divisor != 0));

            return ints;
        }
    }
}
