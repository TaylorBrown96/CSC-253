﻿/**
* 30SEP22
* CSC 253
* Taylor Brown
* Generates a list of prime numbers within a range of the users choosing
*/

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using PrimeNumberLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public static List<int> ints = new List<int>();

        public Form1()
        {
            InitializeComponent();
        }

        // Generates a list based on a users input
        private static void GenerateNums(int range)
        {
            for (int i = 2; i <= range; i++)
            {
                ints.Add(i);
            }
        }

        // Generates a list sends it to get checked and then populates the Listbox 
        private void Btn_Generate_Click(object sender, EventArgs e)
        {
            // Clears the list
            ints.Clear();

            // Gathers the users input and trys to convert it to an integer then 
            // it passes the int to GenereateNums to create a list in range
            try
            {
                int upperRange = int.Parse(TB_UpperRange.Text);
                GenerateNums(upperRange);
            }
            catch 
            {
                MessageBox.Show("Please enter a valid integer!","Error");
                TB_UpperRange.Text = "";
            }

            // Stores the retuned list of primes within the generated list
            List<int> list = Prime.FindPrimes(ints);

            // Clears the listbox then repopulates it
            LB_PrimeNumbers.Items.Clear();
            foreach (int i in list)
            {
                LB_PrimeNumbers.Items.Add(i);
            }
            TB_UpperRange.Text = "";
        }
    }
}
