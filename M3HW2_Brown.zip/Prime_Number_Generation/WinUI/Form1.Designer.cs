﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.L_GenNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_UpperRange = new System.Windows.Forms.TextBox();
            this.LB_PrimeNumbers = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Btn_Generate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // L_GenNumber
            // 
            this.L_GenNumber.AutoSize = true;
            this.L_GenNumber.Location = new System.Drawing.Point(12, 9);
            this.L_GenNumber.Name = "L_GenNumber";
            this.L_GenNumber.Size = new System.Drawing.Size(210, 13);
            this.L_GenNumber.TabIndex = 0;
            this.L_GenNumber.Text = "What would you like your list generated to?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(226, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "2 to ";
            // 
            // TB_UpperRange
            // 
            this.TB_UpperRange.Location = new System.Drawing.Point(250, 6);
            this.TB_UpperRange.Name = "TB_UpperRange";
            this.TB_UpperRange.Size = new System.Drawing.Size(61, 20);
            this.TB_UpperRange.TabIndex = 2;
            // 
            // LB_PrimeNumbers
            // 
            this.LB_PrimeNumbers.FormattingEnabled = true;
            this.LB_PrimeNumbers.Location = new System.Drawing.Point(114, 93);
            this.LB_PrimeNumbers.Name = "LB_PrimeNumbers";
            this.LB_PrimeNumbers.Size = new System.Drawing.Size(123, 355);
            this.LB_PrimeNumbers.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Prime numbers generated within range";
            // 
            // Btn_Generate
            // 
            this.Btn_Generate.Location = new System.Drawing.Point(135, 36);
            this.Btn_Generate.Name = "Btn_Generate";
            this.Btn_Generate.Size = new System.Drawing.Size(82, 23);
            this.Btn_Generate.TabIndex = 5;
            this.Btn_Generate.Text = "Generate";
            this.Btn_Generate.UseVisualStyleBackColor = true;
            this.Btn_Generate.Click += new System.EventHandler(this.Btn_Generate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 463);
            this.Controls.Add(this.Btn_Generate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LB_PrimeNumbers);
            this.Controls.Add(this.TB_UpperRange);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.L_GenNumber);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prime Number Generation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label L_GenNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_UpperRange;
        private System.Windows.Forms.ListBox LB_PrimeNumbers;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_Generate;
    }
}

