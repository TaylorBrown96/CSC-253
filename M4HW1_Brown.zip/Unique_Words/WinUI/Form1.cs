﻿/**
* 20OCT22
* CSC 253
* Taylor J. Brown
* This program allows the user to choose a txt file from anywhere on 
*   their computer. The program will then display the contents of the
*   file and all of the unique words associated with it. 
*/

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using UniqueWordsLibrary;


namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_OpenFile_Click(object sender, EventArgs e)
        {
            // Sets up the openFileDialog object for the user to specify the file location
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = @"C:\";
            openFileDialog1.Title = "Browse Text Files";
            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt";
            openFileDialog1.ShowDialog();

            // Updates the textBox to display the files path
            TB_FilePath.Text = openFileDialog1.FileName;

            // Displays the files contents for the user to view
            RTB_FileContents.Clear();
            RTB_FileContents.Text = File.ReadAllText(openFileDialog1.FileName);

            // Creates a list of unique words and symbols form the FindDuplicates method
            List<string> uniqueWords = Find.Duplicates(File.ReadAllText(openFileDialog1.FileName));

            // Removes any blank strings from the list
            uniqueWords.Remove("");

            // Adds each unique string to the list box
            LB_UniqueWords.Items.Clear();
            foreach (string word in uniqueWords)
            {
                LB_UniqueWords.Items.Add(word);
            }
        }
    }
}
