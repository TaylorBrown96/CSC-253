﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_OpenFile = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.TB_FilePath = new System.Windows.Forms.TextBox();
            this.RTB_FileContents = new System.Windows.Forms.RichTextBox();
            this.LB_UniqueWords = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Btn_OpenFile
            // 
            this.Btn_OpenFile.Location = new System.Drawing.Point(427, 23);
            this.Btn_OpenFile.Name = "Btn_OpenFile";
            this.Btn_OpenFile.Size = new System.Drawing.Size(75, 23);
            this.Btn_OpenFile.TabIndex = 0;
            this.Btn_OpenFile.Text = "Browse";
            this.Btn_OpenFile.UseVisualStyleBackColor = true;
            this.Btn_OpenFile.Click += new System.EventHandler(this.Btn_OpenFile_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "\"txt files (*.txt)|*.txt|All files (*.*)|*.*\"";
            // 
            // TB_FilePath
            // 
            this.TB_FilePath.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.TB_FilePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_FilePath.Location = new System.Drawing.Point(16, 25);
            this.TB_FilePath.Name = "TB_FilePath";
            this.TB_FilePath.ReadOnly = true;
            this.TB_FilePath.Size = new System.Drawing.Size(405, 20);
            this.TB_FilePath.TabIndex = 1;
            // 
            // RTB_FileContents
            // 
            this.RTB_FileContents.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RTB_FileContents.Location = new System.Drawing.Point(12, 72);
            this.RTB_FileContents.Name = "RTB_FileContents";
            this.RTB_FileContents.ReadOnly = true;
            this.RTB_FileContents.Size = new System.Drawing.Size(508, 405);
            this.RTB_FileContents.TabIndex = 2;
            this.RTB_FileContents.Text = "";
            // 
            // LB_UniqueWords
            // 
            this.LB_UniqueWords.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LB_UniqueWords.FormattingEnabled = true;
            this.LB_UniqueWords.Location = new System.Drawing.Point(543, 72);
            this.LB_UniqueWords.Name = "LB_UniqueWords";
            this.LB_UniqueWords.Size = new System.Drawing.Size(292, 405);
            this.LB_UniqueWords.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Text File\'s Contents:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(540, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Unique Words:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Please choose a text file:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(848, 489);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LB_UniqueWords);
            this.Controls.Add(this.RTB_FileContents);
            this.Controls.Add(this.TB_FilePath);
            this.Controls.Add(this.Btn_OpenFile);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Unique Words";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Btn_OpenFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox TB_FilePath;
        private System.Windows.Forms.RichTextBox RTB_FileContents;
        private System.Windows.Forms.ListBox LB_UniqueWords;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

