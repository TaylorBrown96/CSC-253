﻿/**
* 20OCT22
* CSC 253
* Taylor J. Brown
* This class takes in a string argument and returns all the unique 
*   words within the passed string as a list.
*/

using System.Collections.Generic;
using System.Linq;


namespace UniqueWordsLibrary
{
    public class Find
    {
        public static List<string> Duplicates(string contents)
        {
            // Creates an array by spliting the text files words as elements in the array
            string[] array = contents.Split();

            // Uses LINQ to find all distinct words in the array 
            var uniqueWords = array.Distinct().ToList();

            // Returns the uniqueWords List back to the caller 
            return uniqueWords;
        }
    }
}
