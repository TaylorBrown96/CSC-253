﻿namespace WinUI
{
    partial class EditEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Submit = new System.Windows.Forms.Button();
            this.Choice_label = new System.Windows.Forms.Label();
            this.TB_PositionEDIT = new System.Windows.Forms.TextBox();
            this.TB_DepartmentEDIT = new System.Windows.Forms.TextBox();
            this.TB_IDNumberEDIT = new System.Windows.Forms.TextBox();
            this.CB_Employees = new System.Windows.Forms.ComboBox();
            this.Btn_Delete = new System.Windows.Forms.Button();
            this.Btn_Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_Submit
            // 
            this.Btn_Submit.Location = new System.Drawing.Point(122, 55);
            this.Btn_Submit.Name = "Btn_Submit";
            this.Btn_Submit.Size = new System.Drawing.Size(75, 23);
            this.Btn_Submit.TabIndex = 11;
            this.Btn_Submit.Text = "Submit";
            this.Btn_Submit.UseVisualStyleBackColor = true;
            this.Btn_Submit.Click += new System.EventHandler(this.Btn_Submit_Click);
            // 
            // Choice_label
            // 
            this.Choice_label.AutoSize = true;
            this.Choice_label.Location = new System.Drawing.Point(12, 9);
            this.Choice_label.Name = "Choice_label";
            this.Choice_label.Size = new System.Drawing.Size(227, 13);
            this.Choice_label.TabIndex = 10;
            this.Choice_label.Text = "Choose which employee you would like to edit:";
            // 
            // TB_PositionEDIT
            // 
            this.TB_PositionEDIT.Location = new System.Drawing.Point(351, 28);
            this.TB_PositionEDIT.Name = "TB_PositionEDIT";
            this.TB_PositionEDIT.Size = new System.Drawing.Size(100, 20);
            this.TB_PositionEDIT.TabIndex = 9;
            // 
            // TB_DepartmentEDIT
            // 
            this.TB_DepartmentEDIT.Location = new System.Drawing.Point(245, 28);
            this.TB_DepartmentEDIT.Name = "TB_DepartmentEDIT";
            this.TB_DepartmentEDIT.Size = new System.Drawing.Size(100, 20);
            this.TB_DepartmentEDIT.TabIndex = 8;
            // 
            // TB_IDNumberEDIT
            // 
            this.TB_IDNumberEDIT.Location = new System.Drawing.Point(139, 28);
            this.TB_IDNumberEDIT.Name = "TB_IDNumberEDIT";
            this.TB_IDNumberEDIT.Size = new System.Drawing.Size(100, 20);
            this.TB_IDNumberEDIT.TabIndex = 7;
            // 
            // CB_Employees
            // 
            this.CB_Employees.FormattingEnabled = true;
            this.CB_Employees.Location = new System.Drawing.Point(11, 28);
            this.CB_Employees.Name = "CB_Employees";
            this.CB_Employees.Size = new System.Drawing.Size(121, 21);
            this.CB_Employees.TabIndex = 6;
            this.CB_Employees.SelectedIndexChanged += new System.EventHandler(this.CB_Employees_SelectedIndexChanged);
            // 
            // Btn_Delete
            // 
            this.Btn_Delete.Location = new System.Drawing.Point(203, 55);
            this.Btn_Delete.Name = "Btn_Delete";
            this.Btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.Btn_Delete.TabIndex = 12;
            this.Btn_Delete.TabStop = false;
            this.Btn_Delete.Text = "Delete";
            this.Btn_Delete.UseVisualStyleBackColor = true;
            this.Btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // Btn_Cancel
            // 
            this.Btn_Cancel.Location = new System.Drawing.Point(284, 55);
            this.Btn_Cancel.Name = "Btn_Cancel";
            this.Btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.Btn_Cancel.TabIndex = 13;
            this.Btn_Cancel.TabStop = false;
            this.Btn_Cancel.Text = "Cancel";
            this.Btn_Cancel.UseVisualStyleBackColor = true;
            this.Btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // EditEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 85);
            this.Controls.Add(this.Btn_Cancel);
            this.Controls.Add(this.Btn_Delete);
            this.Controls.Add(this.Btn_Submit);
            this.Controls.Add(this.Choice_label);
            this.Controls.Add(this.TB_PositionEDIT);
            this.Controls.Add(this.TB_DepartmentEDIT);
            this.Controls.Add(this.TB_IDNumberEDIT);
            this.Controls.Add(this.CB_Employees);
            this.Name = "EditEmployees";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Employees";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Submit;
        private System.Windows.Forms.Label Choice_label;
        private System.Windows.Forms.TextBox TB_PositionEDIT;
        private System.Windows.Forms.TextBox TB_DepartmentEDIT;
        private System.Windows.Forms.TextBox TB_IDNumberEDIT;
        private System.Windows.Forms.ComboBox CB_Employees;
        private System.Windows.Forms.Button Btn_Delete;
        private System.Windows.Forms.Button Btn_Cancel;
    }
}