﻿/**
* 20NOV22
* CSC 153
* Taylor J. Brown
* This program takes in employee data and creates objects that get displayed to the user
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

namespace WinUI
{
    public partial class EmployeeClass : Form
    {
        public EmployeeClass()
        {
            InitializeComponent();

            // Creates 3 Employee objects
            Employee.Employees.Add(new Employee("Susan Meyers", 47899, "Accounting", "Vice President"));
            Employee.Employees.Add(new Employee("Mark Jones", 39119, "IT", "Programmer"));
            Employee.Employees.Add(new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer"));

            // Adds each object into the listboxes
            for (int i = 0; i < Employee.Employees.Count; i++)
            {
                LB_Names.Items.Add(Employee.Employees[i].Name);
                LB_IDNumbers.Items.Add(Convert.ToString(Employee.Employees[i].IDNumber));
                LB_Departments.Items.Add(Employee.Employees[i].Department);
                LB_Positions.Items.Add(Employee.Employees[i].Position);
            }
        }

        private void Btn_AddEmployee_Click(object sender, EventArgs e)
        {
            // Gets the Employee's name
            string Name = TB_Name.Text;

            int IDNumber = 0;
            // Gets the Employee's IDNumber and trys to convert it to an int
            if (TB_IDNumber.Text.Length != 0)
            {
                try
                {
                    IDNumber = Convert.ToInt32(TB_IDNumber.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid Integer for your employees ID#!", "Error!");

                    // Clears the text box and cancels the process
                    TB_IDNumber.Text = "";
                    return;
                }
            }

            // Gets the Employee's Department
            string Department = TB_Department.Text;

            // Gets the Employee's Position
            string Position = TB_Position.Text;

            // Checks to see if the user didnt add the required information
            if (Name == "" || IDNumber == 0 || Department == "" || Position == "")
            {
                MessageBox.Show("Please enter information about the new employee!", "Needs more Information");
                return;
            }

            // Creates the new object
            Employee.Employees.Add(new Employee(Name, IDNumber, Department, Position));

            // Gets the current working subindex for the employee
            int NumberOfEmployees = Employee.Employees.Count - 1;

            // Adds all new object properties to the list boxes
            LB_Names.Items.Add( Employee.Employees[NumberOfEmployees].Name);
            LB_IDNumbers.Items.Add(Convert.ToString(Employee.Employees[NumberOfEmployees].IDNumber));
            LB_Departments.Items.Add(Employee.Employees[NumberOfEmployees].Department);
            LB_Positions.Items.Add(Employee.Employees[NumberOfEmployees].Position);

            // Clears the text boxes to make multiple entries easier
            TB_Name.Text = "";
            TB_IDNumber.Text = "";
            TB_Department.Text = "";
            TB_Position.Text = "";
        }

        private void Btn_Edit_Click(object sender, EventArgs e)
        {
            // Opens the edit form 
            EditEmployees f2 = new EditEmployees();
            f2.ShowDialog();

            // Clears the list boxes
            LB_Names.Items.Clear();
            LB_IDNumbers.Items.Clear();
            LB_Departments.Items.Clear();
            LB_Positions.Items.Clear();


            // Iterates through each object in the list to populates the list boxes with the new data
            for (int i = 0; i < Employee.Employees.Count; i++)
            {
                LB_Names.Items.Add(Employee.Employees[i].Name);
                LB_IDNumbers.Items.Add(Convert.ToString(Employee.Employees[i].IDNumber));
                LB_Departments.Items.Add(Employee.Employees[i].Department);
                LB_Positions.Items.Add(Employee.Employees[i].Position);
            }
        }
    }
}
