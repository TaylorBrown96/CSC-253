﻿/**
* 20NOV22
* CSC 253
* Taylor J. Browm
* This class library holds the private backing fields and constructors 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Employee
    {
        // Stores all created objects (To referance locally "Employee.Employees")
        public static List<Employee> Employees = new List<Employee>();


        // Backing fields
        private string _Name;
        private int _IDNumber;
        private string _Department;
        private string _Position;

        // Default constructor
        public Employee()
        {
            _Name = "";
            _IDNumber = 0;
            _Department = "";
            _Position = "";
        }

        // Overloaded constructor takes in Name and IDNumber
        public Employee(string Name, int IDNumber)
        {
            _Name = Name;
            _IDNumber = IDNumber;
            _Department = "";
            _Position = "";
        }

        // Overloaded constructor takes in Name, IDNumber, Department, and Position
        public Employee(string Name, int IDNumber, string Department, string Position)
        {
            _Name = Name;
            _IDNumber = IDNumber;
            _Department = Department;
            _Position = Position;
        }

        // Name property
        public string Name { get { return _Name; } set { _Name = value; }}

        // IDNumber property
        public int IDNumber { get { return _IDNumber; } set { _IDNumber = value; }}

        // Department property
        public string Department { get { return _Department; } set { _Department = value; }}

        // Position property
        public string Position { get { return _Position; } set { _Position = value; }}
    }
}
