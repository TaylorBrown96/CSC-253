﻿/**
* 09OCT22
* CSC 253
* Taylor J. Brown
* This program populates a DataGridView from a .csv file and 
* allows the user to use filters to find specific houses 
*/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using HousePriceAnalysisLibrary;
using TextBox = System.Windows.Forms.TextBox;

namespace WinUI
{
    public partial class HousePriceAnalysis : Form
    {
        // Global list of house objects
        public static List<House> houses = new List<House>();

        public static Color red = Color.FromArgb(238, 43, 43);
        public static Color green = Color.FromArgb(192, 246, 132);

        public HousePriceAnalysis()
        {
            InitializeComponent();
            
            // Populates the global list with the data from the .csv file
            // then calls the loadDGV method.
            houses = FileReader.Reader();
            LoadDGV();   
        }

        private void LoadDGV()
        {
            // Clears the DataGridView and re-populates it with the global list
            DGV_Houses.Rows.Clear();
            foreach (House house in houses)
            {
                DGV_Houses.Rows.Add(house.Price.ToString("C"), house.Bedrooms, house.Bathrooms, house.Sqft);
            }
        }

        private void LoadResultsDGV(List<House> list)
        {
            // Clears the DataGridView and then populates it with the passed list
            DGV_Houses.Rows.Clear();
            foreach (House house in list)
            {
                DGV_Houses.Rows.Add(house.Price.ToString("C"), house.Bedrooms, house.Bathrooms, house.Sqft);
            }
        }

        private void ErrorMsg(string message)
        {
            // Displays the user with an error window with the applicable information
            MessageBox.Show( message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


        // Creates a new thread and sends it to the FlashProcess method
        public void Flash(TextBox textBox, Color color)
        {
            new Thread(() => FlashProccess(textBox, color)).Start();
        }

        // Calls the UpdateTextBox method to invoke thread process 
        // applys the color to the background and then reverses the process
        // lastly kills the current thread to prevent memory leaks
        private void FlashProccess(TextBox textBox, Color color)
        {
            Color original = textBox.BackColor;

            UpdateTextbox(textBox, color);
            Thread.Sleep(1000 / 2);
            UpdateTextbox(textBox, original);
            Thread.CurrentThread.Abort();
        }

        // Invokes a new thread to relinquish prior thread proccess tree 
        private delegate void UpdateTextboxDelegate(TextBox textBox, Color originalColor);
        public void UpdateTextbox(TextBox textBox, Color color)
        {
            if (textBox.InvokeRequired) { this.Invoke(new UpdateTextboxDelegate(UpdateTextbox), new object[] { textBox, color }); }
            textBox.BackColor = color;
        }

        private void Btn_ByPrice_Click(object sender, EventArgs e)
        {
            // Checks if the values entered by the user are appropriate
            bool success1 = int.TryParse(TB_PriceLow.Text, out int low);
            bool success2 = int.TryParse(TB_PriceHigh.Text, out int high);

            if (success1 && success2)
            {
                // Searches the global list for the users parameters and populates the new list
                // sends new list to populate the DataGridView.
                List<House> list = houses.FindAll(x => x.Price >= low && x.Price <= high);
                LoadResultsDGV(list);
            }
            else
            {
                // Fail condition met, send user information on failure
                ErrorMsg("Please enter valid prices for your range excluding all symbols.");

                // Decision structure to flash the appropriate textBoxes
                if (!success1 && success2) { Flash(TB_PriceLow, red); }
                else if (success1 && !success2) { Flash(TB_PriceHigh, red); }
                else { Flash(TB_PriceLow, red); Flash(TB_PriceHigh, red); }
            }
        }

        private void Btn_ByBedrooms_Click(object sender, EventArgs e)
        {
            // Checks if the values entered by the user are appropriate
            bool success1 = int.TryParse(TB_BedroomsLow.Text, out int low);
            bool success2 = int.TryParse(TB_BedroomsHigh.Text, out int high);

            if (success1 && success2)
            {
                // Searches the global list for the users parameters and populates the new list
                // sends new list to populate the DataGridView.
                List<House> list = houses.FindAll(x => x.Bedrooms >= low && x.Bedrooms <= high);
                LoadResultsDGV(list);
            }
            else
            {
                // Fail condition met, send user information on failure
                ErrorMsg("Please enter valid integers for your range.");

                // Decision structure to flash the appropriate textBoxes
                if (!success1 && success2) { Flash(TB_BedroomsLow, red); }
                else if (success1 && !success2) { Flash(TB_BedroomsHigh,red); }
                else { Flash(TB_BedroomsLow, red); Flash(TB_BedroomsHigh, red); }
            }
        }

        private void Btn_ByBathrooms_Click(object sender, EventArgs e)
        {
            // Checks if the values entered by the user are appropriate
            bool success1 = int.TryParse(TB_BathroomsLow.Text, out int low);
            bool success2 = int.TryParse(TB_BathroomsHigh.Text, out int high);

            if (success1 && success2)
            {
                // Searches the global list for the users parameters and populates the new list
                // sends new list to populate the DataGridView.
                List<House> list = houses.FindAll(x => x.Bathrooms >= low && x.Bathrooms <= high);
                LoadResultsDGV(list);
            }
            else
            {
                // Fail condition met, send user information on failure
                ErrorMsg("Please enter valid integers for your range.");

                // Decision structure to flash the appropriate textBoxes
                if (!success1 && success2) { Flash(TB_BathroomsLow, red); }
                else if (success1 && !success2) { Flash(TB_BathroomsHigh, red); }
                else { Flash(TB_BathroomsLow, red); Flash(TB_BathroomsHigh, red); }
            }
        }

        private void Btn_BySquareFeet_Click(object sender, EventArgs e)
        {
            // Checks if the values entered by the user are appropriate
            bool success1 = int.TryParse(TB_SquareLow.Text, out int low);
            bool success2 = int.TryParse(TB_SquareHigh.Text, out int high);

            if (success1 && success2)
            {
                // Searches the global list for the users parameters and populates the new list
                // sends new list to populate the DataGridView.
                List<House> list = houses.FindAll(x => x.Sqft >= low && x.Sqft <= high);
                LoadResultsDGV(list);
            }
            else
            {
                // Fail condition met, send user information on failure
                ErrorMsg("Please enter valid integers for your range.");

                // Decision structure to flash the appropriate textBoxes
                if (!success1 && success2) { Flash(TB_SquareLow, red); }
                else if (success1 && !success2) { Flash(TB_SquareHigh, red); }
                else { Flash(TB_SquareLow, red); Flash(TB_SquareHigh, red); }
            }
        }

        private void Btn_ByAll_Click(object sender, EventArgs e)
        {
            // Checks if the values entered by the user are parseable
            bool success1 = int.TryParse(TB_PriceLow.Text, out int PriceLow);
            bool success2 = int.TryParse(TB_PriceHigh.Text, out int PriceHigh);
            bool success3 = int.TryParse(TB_BedroomsLow.Text, out int BedroomsLow);
            bool success4 = int.TryParse(TB_BedroomsHigh.Text, out int BedroomsHigh);
            bool success5 = int.TryParse(TB_BathroomsLow.Text, out int BathroomsLow);
            bool success6 = int.TryParse(TB_BathroomsHigh.Text, out int BathroomsHigh);
            bool success7 = int.TryParse(TB_SquareLow.Text, out int SquareLow);
            bool success8 = int.TryParse(TB_SquareHigh.Text, out int SquareHigh);


            List<House> list = new List<House>();

            // Finds all prices within range
            if (success1 && success2)
            {
                list = houses.FindAll(x => x.Price >= PriceLow && x.Price <= PriceHigh);
            }

            // Finds all bedrooms within range 
            if (success3 && success4)
            {
                if (list.Count != 0)
                {
                    list = list.FindAll(x => x.Bedrooms >= BedroomsLow && x.Bedrooms <= BedroomsHigh);
                }
                else
                {
                    list = houses.FindAll(x => x.Bedrooms >= BedroomsLow && x.Bedrooms <= BedroomsHigh);
                }
            }

            // Finds all bathrooms within range
            if (success5 && success6)
            {
                if (list.Count != 0)
                {
                    list = list.FindAll(x => x.Bathrooms >= BathroomsLow && x.Bathrooms <= BathroomsHigh);
                }
                else
                {
                    list = houses.FindAll(x => x.Bathrooms >= BathroomsLow && x.Bathrooms <= BathroomsHigh);
                }
            }

            // Finds all square footage within range
            if (success7 && success8)
            {
                if (list.Count != 0)
                {
                    list = list.FindAll(x => x.Sqft >= SquareLow && x.Sqft <= SquareHigh);
                }
                else
                {
                    list = houses.FindAll(x => x.Sqft >= SquareLow && x.Sqft <= SquareHigh);
                }
            }

            // Checks if there was a falure in the tryparse and if the length of the input was greater than 0
            if (!success1 && TB_PriceLow.Text.Length != 0) { Flash(TB_PriceLow, red); }
            if (!success2 && TB_PriceHigh.Text.Length != 0) { Flash(TB_PriceHigh, red); }
            if (!success3 && TB_BedroomsLow.Text.Length != 0) { Flash(TB_BedroomsLow, red); }
            if (!success4 && TB_BedroomsHigh.Text.Length != 0) { Flash(TB_BedroomsHigh, red); }
            if (!success5 && TB_BathroomsLow.Text.Length != 0) { Flash(TB_BathroomsLow, red); }
            if (!success6 && TB_BathroomsHigh.Text.Length != 0) { Flash(TB_BathroomsHigh, red); }
            if (!success7 && TB_SquareLow.Text.Length != 0) { Flash(TB_SquareLow, red); }
            if (!success8 && TB_SquareHigh.Text.Length != 0) { Flash(TB_SquareHigh, red); }

            // Loads the DataGridView with the new values from the local list
            LoadResultsDGV(list);
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            // Re-Loads the DataGridView with original content
            LoadDGV();

            // Clears all textBoxes and flashes green
            TB_PriceLow.Text = "";
            Flash(TB_PriceLow, green);
            TB_PriceHigh.Text = "";
            Flash(TB_PriceHigh, green);
            TB_BedroomsLow.Text = "";
            Flash(TB_BedroomsLow, green);
            TB_BedroomsHigh.Text = "";
            Flash(TB_BedroomsHigh, green);
            TB_BathroomsLow.Text = "";
            Flash(TB_BathroomsLow, green);
            TB_BathroomsHigh.Text = "";
            Flash(TB_BathroomsHigh, green);
            TB_SquareLow.Text = "";
            Flash(TB_SquareLow, green);
            TB_SquareHigh.Text = "";
            Flash(TB_SquareHigh, green);
        }
    }
}
