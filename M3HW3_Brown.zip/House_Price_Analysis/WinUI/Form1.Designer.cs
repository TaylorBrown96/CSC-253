﻿
namespace WinUI
{
    partial class HousePriceAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HousePriceAnalysis));
            this.DGV_Houses = new System.Windows.Forms.DataGridView();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bedrooms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Bathrooms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SquareFeet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_PriceLow = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_PriceHigh = new System.Windows.Forms.TextBox();
            this.Btn_ByPrice = new System.Windows.Forms.Button();
            this.Btn_ByBedrooms = new System.Windows.Forms.Button();
            this.TB_BedroomsHigh = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_BedroomsLow = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Btn_ByBathrooms = new System.Windows.Forms.Button();
            this.TB_BathroomsHigh = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_BathroomsLow = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_BySquareFeet = new System.Windows.Forms.Button();
            this.TB_SquareHigh = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TB_SquareLow = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Btn_ByAll = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Houses)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_Houses
            // 
            this.DGV_Houses.AllowUserToAddRows = false;
            this.DGV_Houses.AllowUserToDeleteRows = false;
            this.DGV_Houses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Houses.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Price,
            this.Bedrooms,
            this.Bathrooms,
            this.SquareFeet});
            this.DGV_Houses.Location = new System.Drawing.Point(13, 13);
            this.DGV_Houses.Name = "DGV_Houses";
            this.DGV_Houses.ReadOnly = true;
            this.DGV_Houses.RowHeadersWidth = 51;
            this.DGV_Houses.Size = new System.Drawing.Size(573, 409);
            this.DGV_Houses.TabIndex = 0;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 125;
            // 
            // Bedrooms
            // 
            this.Bedrooms.HeaderText = "Bedrooms";
            this.Bedrooms.MinimumWidth = 6;
            this.Bedrooms.Name = "Bedrooms";
            this.Bedrooms.ReadOnly = true;
            this.Bedrooms.Width = 125;
            // 
            // Bathrooms
            // 
            this.Bathrooms.HeaderText = "Bathrooms";
            this.Bathrooms.MinimumWidth = 6;
            this.Bathrooms.Name = "Bathrooms";
            this.Bathrooms.ReadOnly = true;
            this.Bathrooms.Width = 125;
            // 
            // SquareFeet
            // 
            this.SquareFeet.HeaderText = "Square Feet";
            this.SquareFeet.MinimumWidth = 6;
            this.SquareFeet.Name = "SquareFeet";
            this.SquareFeet.ReadOnly = true;
            this.SquareFeet.Width = 125;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(598, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Price Range:";
            // 
            // TB_PriceLow
            // 
            this.TB_PriceLow.Location = new System.Drawing.Point(672, 135);
            this.TB_PriceLow.Name = "TB_PriceLow";
            this.TB_PriceLow.Size = new System.Drawing.Size(100, 20);
            this.TB_PriceLow.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(779, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "To";
            // 
            // TB_PriceHigh
            // 
            this.TB_PriceHigh.Location = new System.Drawing.Point(806, 135);
            this.TB_PriceHigh.Name = "TB_PriceHigh";
            this.TB_PriceHigh.Size = new System.Drawing.Size(100, 20);
            this.TB_PriceHigh.TabIndex = 4;
            // 
            // Btn_ByPrice
            // 
            this.Btn_ByPrice.Location = new System.Drawing.Point(913, 135);
            this.Btn_ByPrice.Name = "Btn_ByPrice";
            this.Btn_ByPrice.Size = new System.Drawing.Size(146, 23);
            this.Btn_ByPrice.TabIndex = 5;
            this.Btn_ByPrice.Text = "Search by Price";
            this.Btn_ByPrice.UseVisualStyleBackColor = true;
            this.Btn_ByPrice.Click += new System.EventHandler(this.Btn_ByPrice_Click);
            // 
            // Btn_ByBedrooms
            // 
            this.Btn_ByBedrooms.Location = new System.Drawing.Point(913, 164);
            this.Btn_ByBedrooms.Name = "Btn_ByBedrooms";
            this.Btn_ByBedrooms.Size = new System.Drawing.Size(146, 23);
            this.Btn_ByBedrooms.TabIndex = 10;
            this.Btn_ByBedrooms.Text = "Search by # of Bedrooms";
            this.Btn_ByBedrooms.UseVisualStyleBackColor = true;
            this.Btn_ByBedrooms.Click += new System.EventHandler(this.Btn_ByBedrooms_Click);
            // 
            // TB_BedroomsHigh
            // 
            this.TB_BedroomsHigh.Location = new System.Drawing.Point(806, 164);
            this.TB_BedroomsHigh.Name = "TB_BedroomsHigh";
            this.TB_BedroomsHigh.Size = new System.Drawing.Size(100, 20);
            this.TB_BedroomsHigh.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(779, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "To";
            // 
            // TB_BedroomsLow
            // 
            this.TB_BedroomsLow.Location = new System.Drawing.Point(672, 164);
            this.TB_BedroomsLow.Name = "TB_BedroomsLow";
            this.TB_BedroomsLow.Size = new System.Drawing.Size(100, 20);
            this.TB_BedroomsLow.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(606, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Bedrooms:";
            // 
            // Btn_ByBathrooms
            // 
            this.Btn_ByBathrooms.Location = new System.Drawing.Point(913, 190);
            this.Btn_ByBathrooms.Name = "Btn_ByBathrooms";
            this.Btn_ByBathrooms.Size = new System.Drawing.Size(146, 23);
            this.Btn_ByBathrooms.TabIndex = 15;
            this.Btn_ByBathrooms.Text = "Search by # of Bathrooms";
            this.Btn_ByBathrooms.UseVisualStyleBackColor = true;
            this.Btn_ByBathrooms.Click += new System.EventHandler(this.Btn_ByBathrooms_Click);
            // 
            // TB_BathroomsHigh
            // 
            this.TB_BathroomsHigh.Location = new System.Drawing.Point(806, 190);
            this.TB_BathroomsHigh.Name = "TB_BathroomsHigh";
            this.TB_BathroomsHigh.Size = new System.Drawing.Size(100, 20);
            this.TB_BathroomsHigh.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(779, 196);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "To";
            // 
            // TB_BathroomsLow
            // 
            this.TB_BathroomsLow.Location = new System.Drawing.Point(672, 190);
            this.TB_BathroomsLow.Name = "TB_BathroomsLow";
            this.TB_BathroomsLow.Size = new System.Drawing.Size(100, 20);
            this.TB_BathroomsLow.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(606, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Bathrooms:";
            // 
            // Btn_BySquareFeet
            // 
            this.Btn_BySquareFeet.Location = new System.Drawing.Point(913, 216);
            this.Btn_BySquareFeet.Name = "Btn_BySquareFeet";
            this.Btn_BySquareFeet.Size = new System.Drawing.Size(146, 23);
            this.Btn_BySquareFeet.TabIndex = 20;
            this.Btn_BySquareFeet.Text = "Search by Square footage";
            this.Btn_BySquareFeet.UseVisualStyleBackColor = true;
            this.Btn_BySquareFeet.Click += new System.EventHandler(this.Btn_BySquareFeet_Click);
            // 
            // TB_SquareHigh
            // 
            this.TB_SquareHigh.Location = new System.Drawing.Point(806, 216);
            this.TB_SquareHigh.Name = "TB_SquareHigh";
            this.TB_SquareHigh.Size = new System.Drawing.Size(100, 20);
            this.TB_SquareHigh.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(779, 222);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "To";
            // 
            // TB_SquareLow
            // 
            this.TB_SquareLow.Location = new System.Drawing.Point(672, 216);
            this.TB_SquareLow.Name = "TB_SquareLow";
            this.TB_SquareLow.Size = new System.Drawing.Size(100, 20);
            this.TB_SquareLow.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(598, 219);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Square Feet:";
            // 
            // Btn_ByAll
            // 
            this.Btn_ByAll.Location = new System.Drawing.Point(765, 242);
            this.Btn_ByAll.Name = "Btn_ByAll";
            this.Btn_ByAll.Size = new System.Drawing.Size(138, 23);
            this.Btn_ByAll.TabIndex = 21;
            this.Btn_ByAll.Text = "Search by entered filters";
            this.Btn_ByAll.UseVisualStyleBackColor = true;
            this.Btn_ByAll.Click += new System.EventHandler(this.Btn_ByAll_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(678, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(268, 104);
            this.label9.TabIndex = 22;
            this.label9.Text = resources.GetString("label9.Text");
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.Location = new System.Drawing.Point(765, 399);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(138, 23);
            this.Btn_Reset.TabIndex = 23;
            this.Btn_Reset.Text = "Reset The Form";
            this.Btn_Reset.UseVisualStyleBackColor = true;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label10.Location = new System.Drawing.Point(691, 295);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(287, 65);
            this.label10.TabIndex = 24;
            this.label10.Text = resources.GetString("label10.Text");
            // 
            // HousePriceAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 434);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Btn_Reset);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Btn_ByAll);
            this.Controls.Add(this.Btn_BySquareFeet);
            this.Controls.Add(this.TB_SquareHigh);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TB_SquareLow);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Btn_ByBathrooms);
            this.Controls.Add(this.TB_BathroomsHigh);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TB_BathroomsLow);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Btn_ByBedrooms);
            this.Controls.Add(this.TB_BedroomsHigh);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TB_BedroomsLow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Btn_ByPrice);
            this.Controls.Add(this.TB_PriceHigh);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TB_PriceLow);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGV_Houses);
            this.Name = "HousePriceAnalysis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "House Price Analysis";
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Houses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_Houses;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bedrooms;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bathrooms;
        private System.Windows.Forms.DataGridViewTextBoxColumn SquareFeet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_PriceLow;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_PriceHigh;
        private System.Windows.Forms.Button Btn_ByPrice;
        private System.Windows.Forms.Button Btn_ByBedrooms;
        private System.Windows.Forms.TextBox TB_BedroomsHigh;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_BedroomsLow;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_ByBathrooms;
        private System.Windows.Forms.TextBox TB_BathroomsHigh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_BathroomsLow;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_BySquareFeet;
        private System.Windows.Forms.TextBox TB_SquareHigh;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TB_SquareLow;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Btn_ByAll;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Btn_Reset;
        private System.Windows.Forms.Label label10;
    }
}

