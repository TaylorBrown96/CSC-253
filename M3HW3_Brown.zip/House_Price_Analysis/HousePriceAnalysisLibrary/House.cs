﻿/**
* 09OCT22
* CSC 253
* Taylor J. Brown
* This class contains the constructor for the House objects
*/

namespace HousePriceAnalysisLibrary
{
    public class House
    {
        public House(decimal price, int bedrooms, double bathrooms, int sqft)
        {
            Price = price;
            Bedrooms = bedrooms;
            Bathrooms = bathrooms;
            Sqft = sqft;
        }

        public decimal Price { get; set; }
        public int Bedrooms { get; set; }
        public double Bathrooms { get; set; }
        public int Sqft { get; set; }
    }
}
