﻿/**
* 09OCT22
* CSC 253
* Taylor J. Brown
* This program reads a .csv file and creates an object from the data
* and adds the newly created object to a list
*/

using System.Collections.Generic;
using System.IO;
using System.Text;

namespace HousePriceAnalysisLibrary
{
    public class FileReader
    {
        public static List<House> Reader()
        {
            // Creates an empty list for each line of the file to be inserted into
            List<House> houses = new List<House>();

            // Iterates through each line in the text file 
            foreach (string line in File.ReadLines(@"house_prices.csv", Encoding.UTF8))
            {
                string[] Tokens = line.Split(',');

                decimal price = decimal.Parse(Tokens[0]);
                int bedrooms = int.Parse(Tokens[1]);
                double bathrooms = double.Parse(Tokens[2]);
                int sqft = int.Parse(Tokens[3]);
                
                // Creates object based on the line read from the .csv file
                House house = new House(price, bedrooms, bathrooms, sqft);
                houses.Add(house);
            }

            // Returns the populated list back to caller
            return houses;
        }
    }
}
