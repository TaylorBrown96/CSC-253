﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This program allows you input a radius and it will display the
* area of a circle.
*/

using System;
using System.Windows.Forms;
using FormulaLibrary;

namespace WinUI
{
    public partial class CircleForm : Form
    {
        public CircleForm()
        {
            InitializeComponent();
        }

        // This method takes in a double from the textbox on the form and
        // sends it to the area formula class. Then it will update the textbox.
        private void Btn_Calculate_Click(object sender, EventArgs e)
        {
            double radius;
            if (TB_Radius.Text.Length != 0)
            {
                try
                {
                    radius = Convert.ToDouble(TB_Radius.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid double for the radius field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Radius.Text = "";
                    return;
                }
                double area = Calculate.Area(radius);
                TB_Area.Text = area.ToString();
            }
        }
    }
}
