﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This program allows you input a width and a length. It will then display the
* area of a rectangle.
*/

using System;
using System.Windows.Forms;
using FormulaLibrary;

namespace WinUI
{
    public partial class RectangleForm : Form
    {
        public RectangleForm()
        {
            InitializeComponent();
        }

        // This method takes in two decimals from the textbox on the form and
        // sends it to the area formula class. Then it will update the textbox.
        private void Btn_Calculate_Click(object sender, EventArgs e)
        {
            decimal width = 0;
            if (TB_Width.Text.Length != 0)
            {
                try
                {
                    width = Convert.ToDecimal(TB_Width.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid decimal for the width field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Width.Text = "";
                    return;
                }
            }

            decimal length;
            if (TB_Length.Text.Length != 0)
            {
                try
                {
                    length = Convert.ToDecimal(TB_Length.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid decimal for the length field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Length.Text = "";
                    return;
                }
                decimal area = Calculate.Area(width, length);
                TB_Area.Text = area.ToString();
            }
        }
    }
}
