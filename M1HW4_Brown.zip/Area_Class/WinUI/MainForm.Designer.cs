﻿namespace WinUI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Circle = new System.Windows.Forms.Button();
            this.Btn_Rectangle = new System.Windows.Forms.Button();
            this.Btn_Cylinder = new System.Windows.Forms.Button();
            this.L_Question = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_Circle
            // 
            this.Btn_Circle.Location = new System.Drawing.Point(22, 29);
            this.Btn_Circle.Name = "Btn_Circle";
            this.Btn_Circle.Size = new System.Drawing.Size(75, 23);
            this.Btn_Circle.TabIndex = 0;
            this.Btn_Circle.Text = "Circle";
            this.Btn_Circle.UseVisualStyleBackColor = true;
            this.Btn_Circle.Click += new System.EventHandler(this.Btn_Circle_Click);
            // 
            // Btn_Rectangle
            // 
            this.Btn_Rectangle.Location = new System.Drawing.Point(103, 29);
            this.Btn_Rectangle.Name = "Btn_Rectangle";
            this.Btn_Rectangle.Size = new System.Drawing.Size(75, 23);
            this.Btn_Rectangle.TabIndex = 1;
            this.Btn_Rectangle.Text = "Rectangle";
            this.Btn_Rectangle.UseVisualStyleBackColor = true;
            this.Btn_Rectangle.Click += new System.EventHandler(this.Btn_Rectangle_Click);
            // 
            // Btn_Cylinder
            // 
            this.Btn_Cylinder.Location = new System.Drawing.Point(184, 29);
            this.Btn_Cylinder.Name = "Btn_Cylinder";
            this.Btn_Cylinder.Size = new System.Drawing.Size(75, 23);
            this.Btn_Cylinder.TabIndex = 2;
            this.Btn_Cylinder.Text = "Cylinder";
            this.Btn_Cylinder.UseVisualStyleBackColor = true;
            this.Btn_Cylinder.Click += new System.EventHandler(this.Btn_Cylinder_Click);
            // 
            // L_Question
            // 
            this.L_Question.AutoSize = true;
            this.L_Question.Location = new System.Drawing.Point(13, 13);
            this.L_Question.Name = "L_Question";
            this.L_Question.Size = new System.Drawing.Size(258, 13);
            this.L_Question.TabIndex = 3;
            this.L_Question.Text = "What Shape would you like to calculate the area for?";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(85, 58);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(278, 87);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.L_Question);
            this.Controls.Add(this.Btn_Cylinder);
            this.Controls.Add(this.Btn_Rectangle);
            this.Controls.Add(this.Btn_Circle);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Area Class";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Circle;
        private System.Windows.Forms.Button Btn_Rectangle;
        private System.Windows.Forms.Button Btn_Cylinder;
        private System.Windows.Forms.Label L_Question;
        private System.Windows.Forms.Button button1;
    }
}

