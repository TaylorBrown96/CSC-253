﻿namespace WinUI
{
    partial class CylinderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_Height = new System.Windows.Forms.TextBox();
            this.L_Question2 = new System.Windows.Forms.Label();
            this.L_Formula = new System.Windows.Forms.Label();
            this.TB_Area = new System.Windows.Forms.TextBox();
            this.L_Result = new System.Windows.Forms.Label();
            this.Btn_Calculate = new System.Windows.Forms.Button();
            this.TB_Radius = new System.Windows.Forms.TextBox();
            this.L_Question1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TB_Height
            // 
            this.TB_Height.Location = new System.Drawing.Point(12, 67);
            this.TB_Height.Name = "TB_Height";
            this.TB_Height.Size = new System.Drawing.Size(169, 20);
            this.TB_Height.TabIndex = 22;
            // 
            // L_Question2
            // 
            this.L_Question2.AutoSize = true;
            this.L_Question2.Location = new System.Drawing.Point(9, 51);
            this.L_Question2.Name = "L_Question2";
            this.L_Question2.Size = new System.Drawing.Size(168, 13);
            this.L_Question2.TabIndex = 21;
            this.L_Question2.Text = "What is the height of the cylinder?";
            // 
            // L_Formula
            // 
            this.L_Formula.AutoSize = true;
            this.L_Formula.Location = new System.Drawing.Point(209, 74);
            this.L_Formula.Name = "L_Formula";
            this.L_Formula.Size = new System.Drawing.Size(90, 13);
            this.L_Formula.TabIndex = 20;
            this.L_Formula.Text = "Formula: A = πr2h";
            // 
            // TB_Area
            // 
            this.TB_Area.Location = new System.Drawing.Point(209, 42);
            this.TB_Area.Name = "TB_Area";
            this.TB_Area.ReadOnly = true;
            this.TB_Area.Size = new System.Drawing.Size(100, 20);
            this.TB_Area.TabIndex = 19;
            // 
            // L_Result
            // 
            this.L_Result.AutoSize = true;
            this.L_Result.Location = new System.Drawing.Point(206, 24);
            this.L_Result.Name = "L_Result";
            this.L_Result.Size = new System.Drawing.Size(102, 13);
            this.L_Result.TabIndex = 18;
            this.L_Result.Text = "Area of the Cylinder:";
            // 
            // Btn_Calculate
            // 
            this.Btn_Calculate.Location = new System.Drawing.Point(57, 93);
            this.Btn_Calculate.Name = "Btn_Calculate";
            this.Btn_Calculate.Size = new System.Drawing.Size(75, 23);
            this.Btn_Calculate.TabIndex = 17;
            this.Btn_Calculate.Text = "Calculate";
            this.Btn_Calculate.UseVisualStyleBackColor = true;
            this.Btn_Calculate.Click += new System.EventHandler(this.Btn_Calculate_Click);
            // 
            // TB_Radius
            // 
            this.TB_Radius.Location = new System.Drawing.Point(12, 28);
            this.TB_Radius.Name = "TB_Radius";
            this.TB_Radius.Size = new System.Drawing.Size(169, 20);
            this.TB_Radius.TabIndex = 16;
            // 
            // L_Question1
            // 
            this.L_Question1.AutoSize = true;
            this.L_Question1.Location = new System.Drawing.Point(9, 12);
            this.L_Question1.Name = "L_Question1";
            this.L_Question1.Size = new System.Drawing.Size(167, 13);
            this.L_Question1.TabIndex = 15;
            this.L_Question1.Text = "What is the radius of the cylinder?";
            // 
            // CylinderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 123);
            this.Controls.Add(this.TB_Height);
            this.Controls.Add(this.L_Question2);
            this.Controls.Add(this.L_Formula);
            this.Controls.Add(this.TB_Area);
            this.Controls.Add(this.L_Result);
            this.Controls.Add(this.Btn_Calculate);
            this.Controls.Add(this.TB_Radius);
            this.Controls.Add(this.L_Question1);
            this.Name = "CylinderForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Area Class - Cylinder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_Height;
        private System.Windows.Forms.Label L_Question2;
        private System.Windows.Forms.Label L_Formula;
        private System.Windows.Forms.TextBox TB_Area;
        private System.Windows.Forms.Label L_Result;
        private System.Windows.Forms.Button Btn_Calculate;
        private System.Windows.Forms.TextBox TB_Radius;
        private System.Windows.Forms.Label L_Question1;
    }
}