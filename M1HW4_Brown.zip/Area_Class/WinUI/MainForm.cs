﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This program allows you to choose between 3 different shapes and 
* then allows you to calculate the area for each shape.
*/

using System;
using System.Windows.Forms;

namespace WinUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // When the circle button is clicked this method opens the circle form
        private void Btn_Circle_Click(object sender, EventArgs e)
        {
            CircleForm circleForm = new CircleForm();
            circleForm.ShowDialog();
        }

        // When the rectangle button is clicked this method opens the rectangle form
        private void Btn_Rectangle_Click(object sender, EventArgs e)
        {
            RectangleForm rectangleForm = new RectangleForm();
            rectangleForm.ShowDialog();
        }

        // When the cylinder button is clicked this method opens the cylinder form
        private void Btn_Cylinder_Click(object sender, EventArgs e)
        {
            CylinderForm cylinderForm = new CylinderForm();
            cylinderForm.ShowDialog();
        }

        // When the exit button is clicked the program will terminate
        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
