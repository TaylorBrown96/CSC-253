﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This program allows you input a radius and a height. It will then display the
* area of a cylinder.
*/

using System;
using System.Windows.Forms;
using FormulaLibrary;

namespace WinUI
{
    public partial class CylinderForm : Form
    {
        public CylinderForm()
        {
            InitializeComponent();
        }

        // This method takes in two doubles from the textbox on the form and
        // sends it to the area formula class. Then it will update the textbox.
        private void Btn_Calculate_Click(object sender, EventArgs e)
        {
            double radius = 0;
            if (TB_Radius.Text.Length != 0)
            {
                try
                {
                    radius = Convert.ToDouble(TB_Radius.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid double for the radius field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Radius.Text = "";
                    return;
                }
            }

            double height;
            if (TB_Height.Text.Length != 0)
            {
                try
                {
                    height = Convert.ToDouble(TB_Height.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid double for the height field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Height.Text = "";
                    return;
                }
                double area = Calculate.Area(radius, height);
                TB_Area.Text = area.ToString();
            }
        }
    }
}
