﻿/**
* 27AUG22
* CSC 253
* Taylor J. Brown
* This class library contains overloaded methods for calculating the area
* of a circle, rectangle, and a cylinder.
*/

using System;

namespace FormulaLibrary
{
    public class Calculate
    {
        // This method takes in one double and calculates the area of a circle
        public static double Area(double radius)
        {
            double area = Math.PI * (radius * radius);
            return area;
        }

        // This method takes in two decimals and calculates the area of a rectangle
        public static decimal Area(decimal width, decimal length)
        {
            decimal area = width * length;
            return area;
        }

        // This method takes in two doubles and calculates the area of a cylinder
        public static double Area(double radius, double height)
        {
            double area = Math.PI * (radius * radius) * height;
            return area;
        }
    }
}
