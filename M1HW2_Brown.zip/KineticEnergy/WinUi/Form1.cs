﻿/**
* 20AUG22
* CSC 253
* Taylor J. Brown
* This program takes in an objects mass and velocity then
* displays the kenetic energy of that object
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Formula;

namespace WinUi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Calculate_Click(object sender, EventArgs e)
        {
            // Initalizes the mass variable and trys to convert the input to a double
            // if the convertion fails a promt will display and the text box will be zeroed 
            // out.
            double mass = 0.0;
            if (TB_Mass.Text.Length != 0)
            {
                try
                {
                    mass = Convert.ToDouble(TB_Mass.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid double for the mass field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Mass.Text = "";
                    return;
                }
            }

            // Initalizes the velocity variable and trys to convert the input to a double
            // if the convertion fails a promt will display and the text box will be zeroed 
            // out.
            double velocity = 0.0;
            if (TB_Velocity.Text.Length != 0)
            {
                try
                {
                    velocity = Convert.ToDouble(TB_Velocity.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid double for the velocity field!", "Error!");

                    // Clears the text box and cancels the process
                    TB_Velocity.Text = "";
                    return;
                }
            }

            // Calculates the kinetic energy for the inputed variables 
            // then updates the text box.
            double kineticEnergy = Calculate.KineticEnergy(mass,velocity);
            TB_KeneticEnergy.Text = kineticEnergy.ToString();
        }
    }
}
