﻿/**
* 20AUG22
* CSC 253
* Taylor J. Brown
* This class calculates the kenetic energy for the 2 given
* variables then returns the calculation.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Formula
{
    public static class Calculate
    {
        public static double CalculateKE(double mass, double velocity)
        {
            // Formula for calculating kenetic energy 
            // K.E. = 1/2 m v^2
            double kineticEnergy = 0.5 * mass * (velocity * velocity);
            return kineticEnergy;
        }
    }
}
