﻿/**
* 08OCT22
* CSC 253
* Taylor J. Brown
* This class reads a file from the "bin/debug" folder and returns a list of it's contents
*/

using System.Collections.Generic;
using System.Text;
using System.IO;

namespace EnglishSurnamesLibrary
{
    public class ReadFile
    {
        public static List<string> Reader()
        {
            // Creates an empty list for each line of the file to be inserted into
            List<string> surnames = new List<string>();

            // Iterates through each line in the text file 
            foreach (string name in File.ReadLines(@"surnames.txt", Encoding.UTF8))
            {
                surnames.Add(name);
            }

            // Returns the populated list back to caller
            return surnames;
        }
    }
}
