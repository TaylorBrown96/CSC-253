﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_Surnames = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Longer = new System.Windows.Forms.TextBox();
            this.TB_Shorter = new System.Windows.Forms.TextBox();
            this.Btn_SearchRange = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_StartingChar = new System.Windows.Forms.TextBox();
            this.Btn_StartingChars = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_Exist = new System.Windows.Forms.TextBox();
            this.Btn_Exists = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LB_Surnames
            // 
            this.LB_Surnames.FormattingEnabled = true;
            this.LB_Surnames.Location = new System.Drawing.Point(16, 29);
            this.LB_Surnames.Name = "LB_Surnames";
            this.LB_Surnames.Size = new System.Drawing.Size(130, 303);
            this.LB_Surnames.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "English Surnames:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(166, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Search for all names longer than: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(166, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Search for all names shorter than: ";
            // 
            // TB_Longer
            // 
            this.TB_Longer.Location = new System.Drawing.Point(338, 59);
            this.TB_Longer.Name = "TB_Longer";
            this.TB_Longer.Size = new System.Drawing.Size(19, 20);
            this.TB_Longer.TabIndex = 4;
            // 
            // TB_Shorter
            // 
            this.TB_Shorter.Location = new System.Drawing.Point(338, 82);
            this.TB_Shorter.Name = "TB_Shorter";
            this.TB_Shorter.Size = new System.Drawing.Size(19, 20);
            this.TB_Shorter.TabIndex = 5;
            // 
            // Btn_SearchRange
            // 
            this.Btn_SearchRange.Location = new System.Drawing.Point(224, 106);
            this.Btn_SearchRange.Name = "Btn_SearchRange";
            this.Btn_SearchRange.Size = new System.Drawing.Size(75, 23);
            this.Btn_SearchRange.TabIndex = 6;
            this.Btn_SearchRange.Text = "Search";
            this.Btn_SearchRange.UseVisualStyleBackColor = true;
            this.Btn_SearchRange.Click += new System.EventHandler(this.Btn_SearchRange_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(194, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Search by starting charaters:";
            // 
            // TB_StartingChar
            // 
            this.TB_StartingChar.Location = new System.Drawing.Point(168, 157);
            this.TB_StartingChar.Name = "TB_StartingChar";
            this.TB_StartingChar.Size = new System.Drawing.Size(188, 20);
            this.TB_StartingChar.TabIndex = 8;
            // 
            // Btn_StartingChars
            // 
            this.Btn_StartingChars.Location = new System.Drawing.Point(224, 183);
            this.Btn_StartingChars.Name = "Btn_StartingChars";
            this.Btn_StartingChars.Size = new System.Drawing.Size(75, 23);
            this.Btn_StartingChars.TabIndex = 9;
            this.Btn_StartingChars.Text = "Search";
            this.Btn_StartingChars.UseVisualStyleBackColor = true;
            this.Btn_StartingChars.Click += new System.EventHandler(this.Btn_StartingChars_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(211, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Check if name exists:";
            // 
            // TB_Exist
            // 
            this.TB_Exist.Location = new System.Drawing.Point(168, 227);
            this.TB_Exist.Name = "TB_Exist";
            this.TB_Exist.Size = new System.Drawing.Size(188, 20);
            this.TB_Exist.TabIndex = 11;
            // 
            // Btn_Exists
            // 
            this.Btn_Exists.Location = new System.Drawing.Point(224, 253);
            this.Btn_Exists.Name = "Btn_Exists";
            this.Btn_Exists.Size = new System.Drawing.Size(75, 23);
            this.Btn_Exists.TabIndex = 12;
            this.Btn_Exists.Text = "Search";
            this.Btn_Exists.UseVisualStyleBackColor = true;
            this.Btn_Exists.Click += new System.EventHandler(this.Btn_Exists_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(166, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 39);
            this.label6.TabIndex = 13;
            this.label6.Text = "Hint: If you enter numbers in both boxes\r\nit will act as a range where shorter is" +
    " your\r\nupper limit and longer is your lower limit.";
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.Location = new System.Drawing.Point(168, 306);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(188, 24);
            this.Btn_Reset.TabIndex = 14;
            this.Btn_Reset.Text = "Reset The Form";
            this.Btn_Reset.UseVisualStyleBackColor = true;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(372, 345);
            this.Controls.Add(this.Btn_Reset);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Btn_Exists);
            this.Controls.Add(this.TB_Exist);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Btn_StartingChars);
            this.Controls.Add(this.TB_StartingChar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Btn_SearchRange);
            this.Controls.Add(this.TB_Shorter);
            this.Controls.Add(this.TB_Longer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LB_Surnames);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "English Surnames";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LB_Surnames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Longer;
        private System.Windows.Forms.TextBox TB_Shorter;
        private System.Windows.Forms.Button Btn_SearchRange;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_StartingChar;
        private System.Windows.Forms.Button Btn_StartingChars;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_Exist;
        private System.Windows.Forms.Button Btn_Exists;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Reset;
    }
}

