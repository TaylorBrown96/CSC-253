﻿/**
* 08OCT22
* CSC 253
* Taylor J. Brown
* This program uses lambda expresions to search a list of surnames from a file
* the user can search for 
*   -Names longer than specified.
*   -Names shorter than specified.
*   -Names with a length within range of the upper and lower specifications.
*   -Names that start with a specific set of characters. 
*   -Check against all names to see if one exitsts within the list.
*/

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using EnglishSurnamesLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public List<string> surnames = new List<string>();

        public Form1()
        {
            InitializeComponent();

            // Calls the file reader method and loads the ListBox
            surnames = ReadFile.Reader();
            LoadLB();
        }

        private void LoadLB()
        {
            LB_Surnames.Items.Clear();
            foreach (string surname in surnames)
            {
                LB_Surnames.Items.Add(surname);
            }
        }

        private void ErrorMsg(string message, string tittle)
        {
            MessageBox.Show(message, tittle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            TB_Longer.Text = "";
            TB_Shorter.Text = "";
            TB_StartingChar.Text = "";
            TB_Exist.Text = "";
            return;
        }

        private void Btn_SearchRange_Click(object sender, EventArgs e)
        {
            if (TB_Longer.Text.Length != 0 && TB_Shorter.Text.Length == 0)
            {
                int longer;
                bool success = int.TryParse(TB_Longer.Text, out longer);
                if (success)
                {
                    List<string> inRangeLonger = surnames.FindAll(x => x.Length >= longer);

                    LB_Surnames.Items.Clear();
                    foreach (string surname in inRangeLonger)
                    {
                        LB_Surnames.Items.Add(surname);
                    }
                    TB_Longer.Text = "";
                }
                else{ ErrorMsg("Please enter a valid integer","Error!"); }
            }
            else if (TB_Longer.Text.Length == 0 && TB_Shorter.Text.Length != 0)
            {
                int shorter;
                bool success = int.TryParse(TB_Shorter.Text, out shorter);
                if (success)
                {
                    List<string> inRangeShorter = surnames.FindAll(x => x.Length <= shorter);

                    LB_Surnames.Items.Clear();
                    foreach (string surname in inRangeShorter)
                    {
                        LB_Surnames.Items.Add(surname);
                    }
                    TB_Shorter.Text = "";
                }
                else{ ErrorMsg("Please enter a valid integer", "Error!"); }
            }
            else if (TB_Shorter.Text.Length != 0 && TB_Longer.Text.Length != 0)
            {
                int longer;
                int shorter;
                bool success1 = int.TryParse(TB_Longer.Text, out longer);
                bool success2 = int.TryParse(TB_Shorter.Text, out shorter);

                if (success1 && success2)
                {
                    List<string> inRange = surnames.FindAll(x => x.Length >= longer && x.Length <= shorter);

                    LB_Surnames.Items.Clear();
                    foreach (string surname in inRange)
                    {
                        LB_Surnames.Items.Add(surname);
                    }
                    TB_Longer.Text = "";
                    TB_Shorter.Text = "";
                }
                else{ ErrorMsg("Please enter valid integers", "Error!"); }
            }
        }

        private void Btn_StartingChars_Click(object sender, EventArgs e)
        {
            string start = TB_StartingChar.Text.ToLower();
            List<string> starting = surnames.FindAll(x => x.ToLower().StartsWith(start));

            LB_Surnames.Items.Clear();
            foreach (string s in starting)
            {
                LB_Surnames.Items.Add(s);
            }
            TB_StartingChar.Text = "";
        }

        private void Btn_Exists_Click(object sender, EventArgs e)
        {
            string exists = TB_Exist.Text.ToLower();
            List<string> names = surnames.FindAll(x => x.ToLower().Equals(exists));

            LB_Surnames.Items.Clear();
            foreach (string s in names)
            {
                LB_Surnames.Items.Add(s);
            }
            TB_Exist.Text = "";
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            TB_Longer.Text = "";
            TB_Shorter.Text = "";
            TB_StartingChar.Text = "";
            TB_Exist.Text = "";
            LoadLB();
        }
    }
}
