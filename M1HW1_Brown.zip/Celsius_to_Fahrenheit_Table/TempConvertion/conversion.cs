﻿/**
* 20AUG22
* CSC 253
* Taylor J. Brown
* This class converts a given unit into a different unit
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TempConversion
{
    public static class ConvertTemp
    {
        public static double ConvertToFahrenheit(int Celsius)
        {
            // Conversion formula (0°C × 9/5) + 32 = 32°F
            double fahrenheit = (Celsius * 9/5) + 32;
            return fahrenheit;
        }
    }
}
