﻿/*
* 20AUG22
* CSC 253
* Taylor J. Brown
* This program prints out a degree in celsius and its equivalent in fahrenheit in a range of 0-20
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TempConversion;

namespace WinUi
{
    public partial class CelsiustoFahrenheit : Form
    {
        public CelsiustoFahrenheit()
        {
            InitializeComponent();

            /*
             * This for loop uses the sentinal as the celsius and sends 
             * the sentinal to the convertion method class where it 
             * returns the fahrenheit equivalent. 
             */
            for (int i = 0; i < 21; i++)
            {
                LB_Celsius.Items.Add(i.ToString());
                LB_Fahrenheit.Items.Add(ConvertTemp.ConvertToFahrenheit(i).ToString());
            }
        }
    }
}
