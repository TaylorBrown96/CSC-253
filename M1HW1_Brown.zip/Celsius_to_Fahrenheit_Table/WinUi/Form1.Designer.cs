﻿namespace WinUi
{
    partial class CelsiustoFahrenheit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_Celsius = new System.Windows.Forms.ListBox();
            this.LB_Fahrenheit = new System.Windows.Forms.ListBox();
            this.Celsius = new System.Windows.Forms.Label();
            this.Fahrenheit = new System.Windows.Forms.Label();
            this.ConversionFormula = new System.Windows.Forms.Label();
            this.Formula = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LB_Celsius
            // 
            this.LB_Celsius.FormattingEnabled = true;
            this.LB_Celsius.Location = new System.Drawing.Point(12, 25);
            this.LB_Celsius.Name = "LB_Celsius";
            this.LB_Celsius.Size = new System.Drawing.Size(59, 277);
            this.LB_Celsius.TabIndex = 0;
            // 
            // LB_Fahrenheit
            // 
            this.LB_Fahrenheit.FormattingEnabled = true;
            this.LB_Fahrenheit.Location = new System.Drawing.Point(77, 25);
            this.LB_Fahrenheit.Name = "LB_Fahrenheit";
            this.LB_Fahrenheit.Size = new System.Drawing.Size(64, 277);
            this.LB_Fahrenheit.TabIndex = 1;
            // 
            // Celsius
            // 
            this.Celsius.AutoSize = true;
            this.Celsius.Location = new System.Drawing.Point(9, 9);
            this.Celsius.Name = "Celsius";
            this.Celsius.Size = new System.Drawing.Size(40, 13);
            this.Celsius.TabIndex = 2;
            this.Celsius.Text = "Celsius";
            // 
            // Fahrenheit
            // 
            this.Fahrenheit.AutoSize = true;
            this.Fahrenheit.Location = new System.Drawing.Point(74, 9);
            this.Fahrenheit.Name = "Fahrenheit";
            this.Fahrenheit.Size = new System.Drawing.Size(57, 13);
            this.Fahrenheit.TabIndex = 3;
            this.Fahrenheit.Text = "Fahrenheit";
            // 
            // ConversionFormula
            // 
            this.ConversionFormula.AutoSize = true;
            this.ConversionFormula.Location = new System.Drawing.Point(186, 143);
            this.ConversionFormula.Name = "ConversionFormula";
            this.ConversionFormula.Size = new System.Drawing.Size(99, 13);
            this.ConversionFormula.TabIndex = 4;
            this.ConversionFormula.Text = "(°C × 9/5) + 32 = °F";
            // 
            // Formula
            // 
            this.Formula.AutoSize = true;
            this.Formula.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Formula.Location = new System.Drawing.Point(187, 108);
            this.Formula.Name = "Formula";
            this.Formula.Size = new System.Drawing.Size(98, 26);
            this.Formula.TabIndex = 5;
            this.Formula.Text = "Formula:";
            // 
            // CelsiustoFahrenheit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 321);
            this.Controls.Add(this.Formula);
            this.Controls.Add(this.ConversionFormula);
            this.Controls.Add(this.Fahrenheit);
            this.Controls.Add(this.Celsius);
            this.Controls.Add(this.LB_Fahrenheit);
            this.Controls.Add(this.LB_Celsius);
            this.Name = "CelsiustoFahrenheit";
            this.Text = "Celsius to Fahrenheit Table";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LB_Celsius;
        private System.Windows.Forms.ListBox LB_Fahrenheit;
        private System.Windows.Forms.Label Celsius;
        private System.Windows.Forms.Label Fahrenheit;
        private System.Windows.Forms.Label ConversionFormula;
        private System.Windows.Forms.Label Formula;
    }
}

